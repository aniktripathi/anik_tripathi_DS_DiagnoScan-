from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet

def create_sample_health_report(filename="sample_health_report.pdf"):
    """
    Create a sample health report PDF file for testing.
    """
    # Create document
    doc = SimpleDocTemplate(filename, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []
    
    # Add title
    title_style = styles["Heading1"]
    title = Paragraph("Health Examination Report", title_style)
    elements.append(title)
    elements.append(Spacer(1, 20))
    
    # Add patient information
    patient_style = styles["Normal"]
    patient_info = [
        Paragraph(f"<b>Patient Name:</b> John Smith", patient_style),
        Paragraph(f"<b>Patient ID:</b> 12345", patient_style),
        Paragraph(f"<b>Date:</b> April 17, 2025", patient_style),
        Paragraph(f"<b>Age:</b> 45", patient_style),
        Paragraph(f"<b>Gender:</b> Male", patient_style),
        Paragraph(f"<b>Height:</b> 175 cm", patient_style),
        Paragraph(f"<b>Weight:</b> 82 kg", patient_style),
        Paragraph(f"<b>BMI:</b> 26.8", patient_style)
    ]
    
    for info in patient_info:
        elements.append(info)
        elements.append(Spacer(1, 5))
    
    elements.append(Spacer(1, 15))
    
    # Add health metrics table
    elements.append(Paragraph("<b>Blood Test Results</b>", styles["Heading2"]))
    elements.append(Spacer(1, 10))
    
    data = [
        ["Test", "Result", "Reference Range", "Status"],
        ["Glucose (fasting)", "105 mg/dL", "70-99 mg/dL", "High"],
        ["HbA1c", "6.1%", "<5.7%", "High"],
        ["Total Cholesterol", "210 mg/dL", "<200 mg/dL", "High"],
        ["HDL", "42 mg/dL", ">40 mg/dL", "Normal"],
        ["LDL", "130 mg/dL", "<100 mg/dL", "High"],
        ["Triglycerides", "180 mg/dL", "<150 mg/dL", "High"],
        ["VLDL", "38 mg/dL", "<30 mg/dL", "High"],
        ["Non-HDL", "168 mg/dL", "<130 mg/dL", "High"],
        ["TC/HDL Ratio", "5.0", "<4.5", "High"],
        ["ApoB", "110 mg/dL", "<100 mg/dL", "High"],
        ["ApoA1", "120 mg/dL", ">120 mg/dL", "Normal"]
    ]
    
    # Create the table
    table = Table(data, colWidths=[120, 100, 120, 80])
    
    # Add style to the table
    table_style = TableStyle([
        ('BACKGROUND', (0, 0), (3, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (3, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (3, 0), 'CENTER'),
        ('FONTNAME', (0, 0), (3, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (3, 0), 12),
        ('BOTTOMPADDING', (0, 0), (3, 0), 12),
        ('BACKGROUND', (0, 1), (3, 11), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('ALIGN', (1, 1), (3, 11), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('FONTNAME', (0, 1), (0, 11), 'Helvetica-Bold'),
        ('TOPPADDING', (0, 1), (3, 11), 6),
        ('BOTTOMPADDING', (0, 1), (3, 11), 6),
    ])
    table.setStyle(table_style)
    elements.append(table)
    
    elements.append(Spacer(1, 20))
    
    # Add blood pressure information
    elements.append(Paragraph("<b>Blood Pressure</b>", styles["Heading2"]))
    elements.append(Spacer(1, 10))
    elements.append(Paragraph("Blood Pressure: 135/88 mmHg", styles["Normal"]))
    elements.append(Paragraph("Reference Range: <120/80 mmHg", styles["Normal"]))
    elements.append(Paragraph("Status: Stage 1 Hypertension", styles["Normal"]))
    
    elements.append(Spacer(1, 20))
    
    # Add family history
    elements.append(Paragraph("<b>Family Medical History</b>", styles["Heading2"]))
    elements.append(Spacer(1, 10))
    elements.append(Paragraph("Family history of diabetes: Yes (Father)", styles["Normal"]))
    elements.append(Paragraph("Family history of heart disease: Yes (Grandfather)", styles["Normal"]))
    
    elements.append(Spacer(1, 20))
    
    # Add doctor's notes
    elements.append(Paragraph("<b>Doctor's Notes</b>", styles["Heading2"]))
    elements.append(Spacer(1, 10))
    elements.append(Paragraph("Patient shows elevated glucose levels and lipid profile. Recommend lifestyle modifications including diet changes and regular exercise. Follow-up recommended in 3 months.", styles["Normal"]))
    
    # Build the PDF
    doc.build(elements)
    
    print(f"Sample health report created: {filename}")

if __name__ == "__main__":
    create_sample_health_report()