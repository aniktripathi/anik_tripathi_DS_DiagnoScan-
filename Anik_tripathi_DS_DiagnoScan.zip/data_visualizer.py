import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np

def create_blood_metrics_chart(metrics):
    """
    Create a visualization for blood-related health metrics.
    
    Args:
        metrics: Dictionary containing health metrics
    
    Returns:
        plotly.graph_objects.Figure: Plotly figure object for visualization
    """
    # Extract standard blood-related metrics
    glucose = metrics.get("glucose", 0)
    if glucose is None:
        glucose = 0
        
    cholesterol_total = metrics.get("cholesterol", {}).get("total", 0)
    if cholesterol_total is None:
        cholesterol_total = 0
        
    cholesterol_hdl = metrics.get("cholesterol", {}).get("hdl", 0)
    if cholesterol_hdl is None:
        cholesterol_hdl = 0
        
    cholesterol_ldl = metrics.get("cholesterol", {}).get("ldl", 0)
    if cholesterol_ldl is None:
        cholesterol_ldl = 0
        
    triglycerides = metrics.get("triglycerides", 0)
    if triglycerides is None:
        triglycerides = 0
        
    hba1c = metrics.get("hba1c", 0)
    if hba1c is None:
        hba1c = 0
        
    # Extract additional lipid metrics
    vldl = metrics.get("vldl", 0)
    if vldl is None:
        vldl = 0
        
    non_hdl = metrics.get("non_hdl", 0)
    if non_hdl is None:
        non_hdl = 0
        
    apob = metrics.get("apob", 0)
    if apob is None:
        apob = 0
        
    apoa1 = metrics.get("apoa1", 0)
    if apoa1 is None:
        apoa1 = 0
        
    lipid_ratio = metrics.get("lipid_ratio", 0)
    if lipid_ratio is None:
        lipid_ratio = 0
    
    # Define normal ranges for all metrics
    normal_ranges = {
        "Glucose": {"min": 70, "max": 99, "unit": "mg/dL"},
        "Total Cholesterol": {"min": 125, "max": 200, "unit": "mg/dL"},
        "HDL Cholesterol": {"min": 40, "max": 60, "unit": "mg/dL"},
        "LDL Cholesterol": {"min": 0, "max": 100, "unit": "mg/dL"},
        "Triglycerides": {"min": 0, "max": 150, "unit": "mg/dL"},
        "HbA1c": {"min": 4, "max": 5.7, "unit": "%"},
        "VLDL": {"min": 0, "max": 30, "unit": "mg/dL"},
        "Non-HDL": {"min": 0, "max": 130, "unit": "mg/dL"},
        "ApoB": {"min": 0, "max": 100, "unit": "mg/dL"},
        "ApoA1": {"min": 125, "max": 215, "unit": "mg/dL"},
        "TC/HDL Ratio": {"min": 0, "max": 4.0, "unit": ""}
    }
    
    # Determine which metrics to display based on available data
    has_standard_metrics = any([glucose > 0, cholesterol_total > 0, cholesterol_hdl > 0, 
                               cholesterol_ldl > 0, triglycerides > 0, hba1c > 0])
    
    has_lipid_metrics = any([vldl > 0, non_hdl > 0, apob > 0, apoa1 > 0, lipid_ratio > 0])
    
    # Create data for visualization based on available metrics
    if has_standard_metrics:
        # Use standard metrics
        categories = []
        values = []
        
        if glucose > 0:
            categories.append("Glucose")
            values.append(glucose)
        
        if cholesterol_total > 0:
            categories.append("Total Cholesterol")
            values.append(cholesterol_total)
            
        if cholesterol_hdl > 0:
            categories.append("HDL Cholesterol")
            values.append(cholesterol_hdl)
            
        if cholesterol_ldl > 0:
            categories.append("LDL Cholesterol")
            values.append(cholesterol_ldl)
            
        if triglycerides > 0:
            categories.append("Triglycerides")
            values.append(triglycerides)
            
        if hba1c > 0:
            categories.append("HbA1c")
            values.append(hba1c)
    
    # If no standard metrics or if there are lipid metrics, add them
    if has_lipid_metrics or not has_standard_metrics:
        # Initialize categories and values if they don't exist
        if not 'categories' in locals():
            categories = []
            values = []
            
        # Add lipid metrics to the visualization
        if vldl > 0:
            categories.append("VLDL")
            values.append(vldl)
            
        if non_hdl > 0:
            categories.append("Non-HDL")
            values.append(non_hdl)
            
        if apob > 0:
            categories.append("ApoB")
            values.append(apob)
            
        if apoa1 > 0:
            categories.append("ApoA1")
            values.append(apoa1)
            
        if lipid_ratio > 0:
            categories.append("TC/HDL Ratio")
            values.append(lipid_ratio)
            
        # Ensure we have at least one category even if no data is available
        if len(categories) == 0:
            categories = ["No Health Metrics"]
            values = [0]
    
    # Get normal range values for the selected categories
    min_values = [normal_ranges[cat]["min"] if cat in normal_ranges else 0 for cat in categories]
    max_values = [normal_ranges[cat]["max"] if cat in normal_ranges else 100 for cat in categories]
    units = [normal_ranges[cat]["unit"] if cat in normal_ranges else "" for cat in categories]
    
    # Convert to percentage of normal max (for visualization purposes)
    max_percentages = []
    for i, val in enumerate(values):
        if val == 0:  # Skip if value is zero (not provided)
            max_percentages.append(0)
        else:
            normal_max = max_values[i]
            percentage = (val / normal_max) * 100
            max_percentages.append(percentage)
    
    # Create hover texts
    hover_texts = []
    for i, cat in enumerate(categories):
        if values[i] == 0:
            hover_texts.append(f"{cat}: Not Available")
        else:
            status = "Normal" if min_values[i] <= values[i] <= max_values[i] else "Outside Normal Range"
            hover_texts.append(f"{cat}: {values[i]} {units[i]}<br>Normal Range: {min_values[i]}-{max_values[i]} {units[i]}<br>Status: {status}")
    
    # Create colors based on whether values are within normal range
    colors = []
    for i, val in enumerate(values):
        if val == 0:
            colors.append("gray")  # Gray for missing values
        elif min_values[i] <= val <= max_values[i]:
            colors.append("green")  # Green for normal values
        else:
            colors.append("red")    # Red for abnormal values
    
    # Create the bar chart
    fig = go.Figure()
    
    # Add bars for actual values
    fig.add_trace(go.Bar(
        x=categories,
        y=max_percentages,
        text=[f"{val} {unit}" if val > 0 else "N/A" for val, unit in zip(values, units)],
        hovertext=hover_texts,
        marker_color=colors,
        name="Your Values"
    ))
    
    # Add a shape to show normal range
    for i, cat in enumerate(categories):
        if values[i] > 0:  # Only add for available values
            normal_min_pct = (min_values[i] / max_values[i]) * 100
            normal_max_pct = 100  # Since we're using the max as reference
            
            fig.add_shape(
                type="rect",
                x0=i-0.4,
                x1=i+0.4,
                y0=normal_min_pct,
                y1=normal_max_pct,
                line=dict(color="rgba(0,255,0,0.2)", width=2),
                fillcolor="rgba(0,255,0,0.1)"
            )
    
    # Update layout
    fig.update_layout(
        title="Blood Health Metrics",
        xaxis_title="Metric",
        yaxis_title="Percentage of Normal Maximum",
        yaxis=dict(
            range=[0, max(max_percentages) * 1.1]  # Add some padding at the top
        ),
        showlegend=False,
        plot_bgcolor="white"
    )
    
    return fig

def create_risk_gauge(risk_probability):
    """
    Create a gauge chart showing diabetes risk level.
    
    Args:
        risk_probability: Float value representing risk probability (0-1)
    
    Returns:
        plotly.graph_objects.Figure: Plotly figure object for visualization
    """
    # Create gauge chart
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=risk_probability * 100,  # Convert to percentage
        domain={"x": [0, 1], "y": [0, 1]},
        title={"text": "Diabetes Risk"},
        gauge={
            "axis": {"range": [0, 100], "tickwidth": 1, "tickcolor": "darkblue"},
            "bar": {"color": "darkblue"},
            "bgcolor": "white",
            "borderwidth": 2,
            "bordercolor": "gray",
            "steps": [
                {"range": [0, 40], "color": "green"},
                {"range": [40, 70], "color": "yellow"},
                {"range": [70, 100], "color": "red"}
            ],
            "threshold": {
                "line": {"color": "black", "width": 4},
                "thickness": 0.75,
                "value": risk_probability * 100
            }
        }
    ))
    
    # Update layout
    fig.update_layout(
        height=300,
        margin=dict(l=20, r=20, t=50, b=20)
    )
    
    return fig

def create_health_trends(metrics):
    """
    Create a radar chart comparing the patient's metrics to normal values.
    
    Args:
        metrics: Dictionary containing health metrics
    
    Returns:
        plotly.graph_objects.Figure: Plotly figure object for visualization
    """
    # Extract standard metrics
    glucose = metrics.get("glucose", 0)
    if glucose is None:
        glucose = 0
        
    systolic = metrics.get("blood_pressure", {}).get("systolic", 0)
    if systolic is None:
        systolic = 0
        
    diastolic = metrics.get("blood_pressure", {}).get("diastolic", 0)
    if diastolic is None:
        diastolic = 0
        
    cholesterol_total = metrics.get("cholesterol", {}).get("total", 0)
    if cholesterol_total is None:
        cholesterol_total = 0
        
    hdl = metrics.get("cholesterol", {}).get("hdl", 0)
    if hdl is None:
        hdl = 0
        
    ldl = metrics.get("cholesterol", {}).get("ldl", 0)
    if ldl is None:
        ldl = 0
        
    triglycerides = metrics.get("triglycerides", 0)
    if triglycerides is None:
        triglycerides = 0
        
    bmi = metrics.get("bmi", 0)
    if bmi is None:
        bmi = 0
    
    # Extract additional lipid metrics
    vldl = metrics.get("vldl", 0)
    if vldl is None:
        vldl = 0
        
    non_hdl = metrics.get("non_hdl", 0)
    if non_hdl is None:
        non_hdl = 0
        
    apob = metrics.get("apob", 0)
    if apob is None:
        apob = 0
        
    apoa1 = metrics.get("apoa1", 0)
    if apoa1 is None:
        apoa1 = 0
        
    lipid_ratio = metrics.get("lipid_ratio", 0)
    if lipid_ratio is None:
        lipid_ratio = 0
    
    # Determine which type of metrics to display based on available data
    has_standard_metrics = any([glucose > 0, systolic > 0, diastolic > 0, cholesterol_total > 0, triglycerides > 0, bmi > 0])
    has_lipid_metrics = any([vldl > 0, non_hdl > 0, apob > 0, apoa1 > 0, lipid_ratio > 0, hdl > 0, ldl > 0])
    
    # Define normal values for different metrics types
    if has_standard_metrics:
        # Standard health metrics
        normal_values = {
            "Glucose": 90,
            "Systolic BP": 120,
            "Diastolic BP": 80,
            "Total Cholesterol": 180,
            "Triglycerides": 120,
            "BMI": 22
        }
        
        # Get patient values for standard metrics
        categories = list(normal_values.keys())
        patient_values = [glucose, systolic, diastolic, cholesterol_total, triglycerides, bmi]
    
    elif has_lipid_metrics:
        # Lipid profile metrics
        normal_values = {}
        categories = []
        patient_values = []
        
        # Only add metrics that are available
        if hdl > 0:
            normal_values["HDL"] = 50
            categories.append("HDL")
            patient_values.append(hdl)
            
        if ldl > 0:
            normal_values["LDL"] = 100
            categories.append("LDL")
            patient_values.append(ldl)
            
        if vldl > 0:
            normal_values["VLDL"] = 30
            categories.append("VLDL")
            patient_values.append(vldl)
            
        if non_hdl > 0:
            normal_values["Non-HDL"] = 130
            categories.append("Non-HDL")
            patient_values.append(non_hdl)
            
        if apob > 0:
            normal_values["ApoB"] = 100
            categories.append("ApoB")
            patient_values.append(apob)
            
        if apoa1 > 0:
            normal_values["ApoA1"] = 125
            categories.append("ApoA1")
            patient_values.append(apoa1)
            
        if lipid_ratio > 0:
            normal_values["TC/HDL Ratio"] = 4.0
            categories.append("TC/HDL Ratio")
            patient_values.append(lipid_ratio)
            
        if cholesterol_total > 0:
            normal_values["Total Cholesterol"] = 180
            categories.append("Total Cholesterol")
            patient_values.append(cholesterol_total)
            
        if triglycerides > 0:
            normal_values["Triglycerides"] = 120
            categories.append("Triglycerides")
            patient_values.append(triglycerides)
    
    else:
        # Default to some basic metrics if nothing specific is available
        normal_values = {
            "Health Metrics": 100
        }
        categories = ["Health Metrics"]
        patient_values = [0]
    
    # Calculate percentage of normal values
    normal_percentages = []
    patient_percentages = []
    
    for i, cat in enumerate(categories):
        normal_val = normal_values[cat]
        patient_val = patient_values[i]
        
        # Skip if patient value is missing
        if patient_val == 0:
            normal_percentages.append(0)
            patient_percentages.append(0)
            continue
        
        # Calculate percentages
        # For BMI, use a different approach since both high and low can be abnormal
        if cat == "BMI":
            normal_percentages.append(100)
            if patient_val < 18.5:
                # Underweight
                patient_percentages.append(patient_val / 18.5 * 100)
            elif patient_val <= 25:
                # Normal
                patient_percentages.append(100)
            else:
                # Overweight/Obese - higher percentage means more deviation from normal
                patient_percentages.append(100 + (patient_val - 25) / 25 * 100)
        # For HDL, higher is better
        elif cat == "HDL" or cat == "ApoA1":
            normal_percentages.append(100)
            # If patient HDL is higher than normal, that's good
            if patient_val >= normal_val:
                patient_percentages.append(100)
            else:
                # If lower than normal, show the percentage of normal
                patient_percentages.append((patient_val / normal_val) * 100)
        else:
            # For other metrics, higher than normal is generally worse
            normal_percentages.append(100)
            patient_percentages.append((patient_val / normal_val) * 100)
    
    # Create the radar chart
    fig = go.Figure()
    
    # Add trace for normal values
    fig.add_trace(go.Scatterpolar(
        r=normal_percentages,
        theta=categories,
        fill='toself',
        name='Normal Range',
        line_color='green',
        fillcolor='rgba(0, 255, 0, 0.2)'
    ))
    
    # Add trace for patient values
    fig.add_trace(go.Scatterpolar(
        r=patient_percentages,
        theta=categories,
        fill='toself',
        name='Your Values',
        line_color='blue',
        fillcolor='rgba(0, 0, 255, 0.2)'
    ))
    
    # Update layout
    fig.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, max(max(normal_percentages, default=100), max(patient_percentages, default=100)) * 1.1]
            )
        ),
        showlegend=True,
        title="Health Metrics Comparison"
    )
    
    return fig
