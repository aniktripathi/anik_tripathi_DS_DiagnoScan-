import re
import io
import PyPDF2
import pandas as pd
import streamlit as st
from io import BytesIO

# We're not using NLTK's tokenization to avoid dependency issues
# import nltk
# from nltk.tokenize import sent_tokenize, word_tokenize

def extract_text_from_pdf(pdf_file):
    """
    Extract text content from uploaded PDF file.
    
    Args:
        pdf_file: StreamlitUploadedFile object containing the PDF
    
    Returns:
        str: Extracted text from the PDF
    """
    try:
        # Reset file pointer to the beginning
        pdf_file.seek(0)
        
        # Read the PDF content
        pdf_reader = PyPDF2.PdfReader(BytesIO(pdf_file.read()))
        
        # Extract text from all pages
        text = ""
        for page_num in range(len(pdf_reader.pages)):
            page = pdf_reader.pages[page_num]
            text += page.extract_text()
        
        return text
    except Exception as e:
        st.error(f"Error extracting text from PDF: {str(e)}")
        return None

def extract_health_metrics(text):
    """
    Extract health metrics from the PDF text using regular expressions
    and natural language processing techniques.
    
    Args:
        text: String containing the PDF content
    
    Returns:
        dict: Dictionary of extracted health metrics
    """
    if not text:
        raise ValueError("No text content found in the PDF")
    
    # Initialize metrics dictionary with default values
    metrics = {
        "glucose": None,
        "blood_pressure": {"systolic": None, "diastolic": None},
        "cholesterol": {"total": None, "hdl": None, "ldl": None},
        "triglycerides": None,
        "bmi": None,
        "age": None,
        "gender": None,
        "family_history": False,
        "hba1c": None,
        "weight": None,
        "height": None,
        # Additional lipid metrics
        "vldl": None,
        "non_hdl": None,
        "apob": None,
        "apoa1": None,
        "lipid_ratio": None
    }
    
    # Tokenize the text using simple splitting instead of nltk tokenizer to avoid dependency issues
    # sentences = sent_tokenize(text)
    sentences = [s.strip() for s in re.split(r'[\.\n]+', text) if s.strip()]
    
    # Extract metrics using regex patterns
    
    # Glucose
    glucose_pattern = r"(?:fasting )?glucose[:\s]*([\d\.]+)(?:\s*(?:mg/dL|mmol/L))"
    glucose_matches = re.findall(glucose_pattern, text, re.IGNORECASE)
    if glucose_matches:
        metrics["glucose"] = float(glucose_matches[0])
    
    # Blood Pressure
    bp_pattern = r"blood pressure[:\s]*(\d+)[/\s]*(\d+)(?:\s*mmHg)?"
    bp_matches = re.findall(bp_pattern, text, re.IGNORECASE)
    if bp_matches:
        metrics["blood_pressure"]["systolic"] = int(bp_matches[0][0])
        metrics["blood_pressure"]["diastolic"] = int(bp_matches[0][1])
    
    # Cholesterol
    total_chol_pattern = r"(?:total )?cholesterol[:\s]*([\d\.]+)(?:\s*(?:mg/dL|mmol/L))"
    total_chol_matches = re.findall(total_chol_pattern, text, re.IGNORECASE)
    if total_chol_matches:
        metrics["cholesterol"]["total"] = float(total_chol_matches[0])
    
    hdl_pattern = r"HDL[:\s]*([\d\.]+)(?:\s*(?:mg/dL|mmol/L))"
    hdl_matches = re.findall(hdl_pattern, text, re.IGNORECASE)
    if hdl_matches:
        metrics["cholesterol"]["hdl"] = float(hdl_matches[0])
    
    ldl_pattern = r"LDL[:\s]*([\d\.]+)(?:\s*(?:mg/dL|mmol/L))"
    ldl_matches = re.findall(ldl_pattern, text, re.IGNORECASE)
    if ldl_matches:
        metrics["cholesterol"]["ldl"] = float(ldl_matches[0])
    
    # Triglycerides
    trig_pattern = r"triglycerides[:\s]*([\d\.]+)(?:\s*(?:mg/dL|mmol/L))"
    trig_matches = re.findall(trig_pattern, text, re.IGNORECASE)
    if trig_matches:
        metrics["triglycerides"] = float(trig_matches[0])
        
    # Additional Lipid Metrics
    
    # VLDL (Very Low-Density Lipoprotein)
    vldl_pattern = r"VLDL[:\s]*([\d\.]+)(?:\s*(?:mg/dL|mmol/L))"
    vldl_matches = re.findall(vldl_pattern, text, re.IGNORECASE)
    if vldl_matches:
        metrics["vldl"] = float(vldl_matches[0])
    
    # Non-HDL Cholesterol
    non_hdl_pattern = r"(?:non-HDL|non HDL)[:\s]*([\d\.]+)(?:\s*(?:mg/dL|mmol/L))"
    non_hdl_matches = re.findall(non_hdl_pattern, text, re.IGNORECASE)
    if non_hdl_matches:
        metrics["non_hdl"] = float(non_hdl_matches[0])
    
    # ApoB (Apolipoprotein B)
    apob_pattern = r"(?:ApoB|Apolipoprotein B)[:\s]*([\d\.]+)(?:\s*(?:mg/dL|g/L))"
    apob_matches = re.findall(apob_pattern, text, re.IGNORECASE)
    if apob_matches:
        metrics["apob"] = float(apob_matches[0])
    
    # ApoA1 (Apolipoprotein A1)
    apoa1_pattern = r"(?:ApoA1|ApoA-1|Apolipoprotein A1|Apolipoprotein A-1)[:\s]*([\d\.]+)(?:\s*(?:mg/dL|g/L))"
    apoa1_matches = re.findall(apoa1_pattern, text, re.IGNORECASE)
    if apoa1_matches:
        metrics["apoa1"] = float(apoa1_matches[0])
    
    # Lipid Ratio (Total Cholesterol/HDL)
    lipid_ratio_pattern = r"(?:TC/HDL|Total Cholesterol/HDL|Cholesterol Ratio)[:\s]*([\d\.]+)"
    lipid_ratio_matches = re.findall(lipid_ratio_pattern, text, re.IGNORECASE)
    if lipid_ratio_matches:
        metrics["lipid_ratio"] = float(lipid_ratio_matches[0])
    
    # BMI
    bmi_pattern = r"BMI[:\s]*([\d\.]+)"
    bmi_matches = re.findall(bmi_pattern, text, re.IGNORECASE)
    if bmi_matches:
        metrics["bmi"] = float(bmi_matches[0])
    
    # Age
    age_pattern = r"(?:age|years old)[:\s]*(\d+)"
    age_matches = re.findall(age_pattern, text, re.IGNORECASE)
    if age_matches:
        metrics["age"] = int(age_matches[0])
    
    # Gender
    if re.search(r'\b(?:male|man)\b', text, re.IGNORECASE):
        metrics["gender"] = "male"
    elif re.search(r'\b(?:female|woman)\b', text, re.IGNORECASE):
        metrics["gender"] = "female"
    
    # Family History
    family_pattern = r"family history of diabetes"
    if re.search(family_pattern, text, re.IGNORECASE):
        metrics["family_history"] = True
    
    # HbA1c
    hba1c_pattern = r"(?:HbA1c|A1c)[:\s]*([\d\.]+)(?:\s*\%)?"
    hba1c_matches = re.findall(hba1c_pattern, text, re.IGNORECASE)
    if hba1c_matches:
        metrics["hba1c"] = float(hba1c_matches[0])
    
    # Weight
    weight_pattern = r"weight[:\s]*([\d\.]+)(?:\s*(?:kg|pounds|lbs))"
    weight_matches = re.findall(weight_pattern, text, re.IGNORECASE)
    if weight_matches:
        metrics["weight"] = float(weight_matches[0])
    
    # Height
    height_pattern = r"height[:\s]*([\d\.]+)(?:\s*(?:cm|m|ft|inches))"
    height_matches = re.findall(height_pattern, text, re.IGNORECASE)
    if height_matches:
        metrics["height"] = float(height_matches[0])
    
    # Check if we found any health metrics
    primary_metrics_found = any(v is not None and not (isinstance(v, dict) and all(sv is None for sv in v.values())) 
                               for k, v in metrics.items() 
                               if k in ["glucose", "blood_pressure", "cholesterol", "triglycerides", "bmi", "hba1c"])
    
    # Check if we found any additional lipid metrics
    lipid_metrics_found = any(metrics[k] is not None for k in ["vldl", "non_hdl", "apob", "apoa1", "lipid_ratio"])
    
    # If neither primary health metrics nor additional lipid metrics were found
    if not primary_metrics_found and not lipid_metrics_found:
        # Raise an error
        raise ValueError("Could not extract sufficient health metrics from the report. Please ensure your report contains standard health metrics or lipid profile information.")
    
    # Fill in missing metrics with estimated values for demo purposes
    if metrics["bmi"] is None and metrics["weight"] is not None and metrics["height"] is not None:
        # Calculate BMI if height and weight are available
        # Assuming height is in cm and weight in kg
        height_m = metrics["height"] / 100  # convert to meters
        metrics["bmi"] = metrics["weight"] / (height_m ** 2)
    
    return metrics
