import numpy as np
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.model_selection import train_test_split
import streamlit as st
import pandas as pd

def get_feature_vector(metrics):
    """
    Convert health metrics dictionary to a feature vector for prediction.
    
    Args:
        metrics: Dictionary containing health metrics
    
    Returns:
        numpy.ndarray: Feature vector for SVM model
    """
    # Define the features we'll use for prediction
    features = []
    
    # Glucose (fasting blood sugar)
    glucose = metrics.get("glucose", 0)
    if glucose is None:
        glucose = 0
    features.append(glucose)
    
    # Blood pressure (systolic)
    systolic = metrics.get("blood_pressure", {}).get("systolic", 0)
    if systolic is None:
        systolic = 0
    features.append(systolic)
    
    # Blood pressure (diastolic)
    diastolic = metrics.get("blood_pressure", {}).get("diastolic", 0)
    if diastolic is None:
        diastolic = 0
    features.append(diastolic)
    
    # BMI
    bmi = metrics.get("bmi", 0)
    if bmi is None:
        bmi = 0
    features.append(bmi)
    
    # Age
    age = metrics.get("age", 0)
    if age is None:
        age = 0
    features.append(age)
    
    # Cholesterol metrics
    total_chol = metrics.get("cholesterol", {}).get("total", 0)
    if total_chol is None:
        total_chol = 0
    features.append(total_chol)
    
    hdl = metrics.get("cholesterol", {}).get("hdl", 0)
    if hdl is None:
        hdl = 0
    features.append(hdl)
    
    ldl = metrics.get("cholesterol", {}).get("ldl", 0)
    if ldl is None:
        ldl = 0
    features.append(ldl)
    
    # Triglycerides
    triglycerides = metrics.get("triglycerides", 0)
    if triglycerides is None:
        triglycerides = 0
    features.append(triglycerides)
    
    # HbA1c
    hba1c = metrics.get("hba1c", 0)
    if hba1c is None:
        hba1c = 0
    features.append(hba1c)
    
    # Gender (binary encoding)
    gender = 1 if metrics.get("gender") == "male" else 0
    features.append(gender)
    
    # Family history (binary encoding)
    family_history = 1 if metrics.get("family_history") else 0
    features.append(family_history)
    
    return np.array(features).reshape(1, -1)

def train_svm_model(return_data=False):
    """
    Train an SVM model for diabetes prediction.
    
    This is a simplified model for demonstration purposes.
    In a real application, you would use a properly trained
    and validated model from a larger dataset.
    
    Args:
        return_data: If True, also return training and test data for evaluation
    
    Returns:
        tuple: (model, scaler, [X_train, X_test, y_train, y_test]) - Trained SVM model, feature scaler, and data splits if requested
    """
    # For demonstration, we'll create a simple model based on common medical knowledge
    # In a real application, this would be trained on a large dataset
    
    # Create a synthetic training dataset based on medical knowledge about diabetes risk factors
    # Each row represents: [glucose, systolic, diastolic, bmi, age, total_chol, hdl, ldl, triglycerides, hba1c, gender, family_history]
    X = np.array([
        # Low risk examples
        [85, 120, 80, 22, 35, 180, 55, 100, 120, 5.2, 0, 0],  # Healthy young female
        [90, 125, 82, 23, 40, 190, 50, 110, 130, 5.4, 1, 0],  # Healthy middle-age male
        [92, 130, 85, 24, 45, 200, 48, 115, 140, 5.5, 0, 0],  # Healthy middle-age female
        [88, 118, 75, 21, 30, 175, 60, 95, 110, 5.0, 1, 0],   # Very healthy young male
        
        # Moderate risk examples
        [105, 135, 88, 27, 50, 220, 42, 140, 160, 5.8, 1, 0],  # Middle-age male with some risk
        [110, 140, 90, 29, 55, 230, 40, 150, 180, 6.0, 0, 1],  # Middle-age female with family history
        [115, 145, 92, 30, 60, 240, 38, 160, 200, 6.2, 1, 0],  # Older male with elevated metrics
        
        # High risk examples
        [126, 150, 95, 32, 65, 250, 35, 170, 220, 6.5, 0, 1],  # Older female with high metrics
        [135, 155, 98, 34, 70, 260, 32, 180, 240, 6.8, 1, 1],  # Older male with high metrics & family history
        [140, 160, 100, 36, 75, 270, 30, 190, 260, 7.0, 0, 1], # Elderly female with high metrics & family history
        [150, 170, 105, 38, 80, 280, 28, 200, 280, 7.5, 1, 1]  # Elderly male with very high metrics & family history
    ])
    
    # Target labels: 0 = low risk, 1 = high risk
    y = np.array([0, 0, 0, 0, 0.5, 0.5, 0.5, 1, 1, 1, 1])
    
    # Create additional synthetic samples for better evaluation
    # Duplicate some samples with slight variations to increase dataset size
    X_expanded = np.vstack([X, X + np.random.normal(0, 0.05, X.shape)])
    y_expanded = np.concatenate([y, y])
    
    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X_expanded, y_expanded, test_size=0.3, random_state=42)
    
    # Scale the features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Train SVM model with probability estimates
    model = SVC(kernel='rbf', probability=True)
    model.fit(X_train_scaled, y_train)
    
    if return_data:
        return model, scaler, (X_train_scaled, X_test_scaled, y_train, y_test)
    else:
        return model, scaler

def predict_diabetes_risk(metrics):
    """
    Predict diabetes risk based on health metrics.
    
    Args:
        metrics: Dictionary containing health metrics
    
    Returns:
        dict: Prediction results including risk probability and confidence
    """
    try:
        # Get feature vector from metrics
        X = get_feature_vector(metrics)
        
        # Train model (in a real application, this would be a pre-trained model)
        model, scaler = train_svm_model()
        
        # Scale features
        X_scaled = scaler.transform(X)
        
        # Get prediction probability
        risk_probability = model.predict_proba(X_scaled)[0]
        
        # Calculate confidence score based on distance to decision boundary
        decision_confidence = abs(model.decision_function(X_scaled)[0])
        normalized_confidence = min(1.0, decision_confidence / 3.0)  # Normalize to 0-1 scale
        
        # Calculate feature importance
        # For SVM, we can use the coefficients for linear kernel, or approximate importance
        # based on sensitivity analysis for non-linear kernels
        
        # Define feature names
        feature_names = [
            "Glucose", "Systolic BP", "Diastolic BP", "BMI", "Age",
            "Total Cholesterol", "HDL", "LDL", "Triglycerides", "HbA1c",
            "Gender", "Family History"
        ]
        
        # Calculate a crude feature importance by sensitivity analysis
        feature_importance = {}
        base_prediction = model.predict_proba(X_scaled)[0][1]  # Baseline prediction
        
        for i, feature_name in enumerate(feature_names):
            # Create a modified feature vector with this feature increased by 10%
            X_modified = X_scaled.copy()
            X_modified[0, i] += 0.5  # Increase by 0.5 standard deviations
            
            # Get new prediction
            new_prediction = model.predict_proba(X_modified)[0][1]
            
            # Calculate importance as difference in prediction
            importance = abs(new_prediction - base_prediction)
            feature_importance[feature_name] = importance
        
        # Normalize feature importance
        total_importance = sum(feature_importance.values())
        if total_importance > 0:
            for feature in feature_importance:
                feature_importance[feature] /= total_importance
        
        # Calculate risk class based on probability
        if risk_probability[1] < 0.4:
            risk_class = "Low Risk"
        elif risk_probability[1] < 0.7:
            risk_class = "Moderate Risk"
        else:
            risk_class = "High Risk"
        
        return {
            "probability": float(risk_probability[1]),
            "class": risk_class,
            "confidence": float(normalized_confidence),
            "feature_importance": feature_importance
        }
    
    except Exception as e:
        st.error(f"Error predicting diabetes risk: {str(e)}")
        return {
            "probability": 0.0,
            "class": "Error",
            "confidence": 0.0,
            "feature_importance": {}
        }

def evaluate_model():
    """
    Evaluate the SVM model for diabetes prediction.
    
    Returns:
        dict: Dictionary containing model evaluation metrics
    """
    try:
        # Train model and get training/testing data
        model, scaler, (X_train, X_test, y_train, y_test) = train_svm_model(return_data=True)
        
        # Make predictions on training and testing data
        y_train_pred = model.predict(X_train)
        y_test_pred = model.predict(X_test)
        
        # Evaluate the model on training data
        train_accuracy = accuracy_score(y_train, y_train_pred)
        train_precision = precision_score(y_train, y_train_pred, average='weighted')
        train_recall = recall_score(y_train, y_train_pred, average='weighted')
        train_f1 = f1_score(y_train, y_train_pred, average='weighted')
        
        # Evaluate the model on testing data
        test_accuracy = accuracy_score(y_test, y_test_pred)
        test_precision = precision_score(y_test, y_test_pred, average='weighted')
        test_recall = recall_score(y_test, y_test_pred, average='weighted')
        test_f1 = f1_score(y_test, y_test_pred, average='weighted')
        
        # Calculate confusion matrix
        cm = confusion_matrix(y_test, y_test_pred)
        
        # Get feature names for importance calculation
        feature_names = [
            "Glucose", "Systolic BP", "Diastolic BP", "BMI", "Age",
            "Total Cholesterol", "HDL", "LDL", "Triglycerides", "HbA1c",
            "Gender", "Family History"
        ]
        
        # Calculate feature importance (using the same method as in predict_diabetes_risk)
        feature_importance = {}
        
        # Use a neutral sample for calculating feature importance
        neutral_sample = np.zeros((1, len(feature_names)))
        neutral_sample_scaled = scaler.transform(neutral_sample)
        base_prediction = model.predict_proba(neutral_sample_scaled)[0][1]
        
        for i, feature_name in enumerate(feature_names):
            # Create a modified feature vector with this feature increased
            X_modified = neutral_sample_scaled.copy()
            X_modified[0, i] += 1.0  # Increase by 1 standard deviation
            
            # Get new prediction
            new_prediction = model.predict_proba(X_modified)[0][1]
            
            # Calculate importance as difference in prediction
            importance = abs(new_prediction - base_prediction)
            feature_importance[feature_name] = importance
        
        # Normalize feature importance
        total_importance = sum(feature_importance.values())
        if total_importance > 0:
            for feature in feature_importance:
                feature_importance[feature] /= total_importance
        
        # Return dictionary with evaluation metrics
        return {
            "training": {
                "accuracy": float(train_accuracy),
                "precision": float(train_precision),
                "recall": float(train_recall),
                "f1_score": float(train_f1)
            },
            "testing": {
                "accuracy": float(test_accuracy),
                "precision": float(test_precision),
                "recall": float(test_recall),
                "f1_score": float(test_f1)
            },
            "confusion_matrix": cm.tolist(),
            "feature_importance": feature_importance
        }
    
    except Exception as e:
        st.error(f"Error evaluating model: {str(e)}")
        return {
            "training": {
                "accuracy": 0.0,
                "precision": 0.0,
                "recall": 0.0,
                "f1_score": 0.0
            },
            "testing": {
                "accuracy": 0.0,
                "precision": 0.0,
                "recall": 0.0,
                "f1_score": 0.0
            },
            "confusion_matrix": [[0, 0], [0, 0]],
            "feature_importance": {}
        }
