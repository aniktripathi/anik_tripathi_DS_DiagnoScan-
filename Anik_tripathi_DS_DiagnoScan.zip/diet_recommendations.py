import streamlit as st

def get_diet_recommendations(metrics, risk_assessment):
    """
    Generate personalized diet recommendations based on health metrics
    and diabetes risk assessment.
    
    Args:
        metrics: Dictionary containing health metrics
        risk_assessment: Dictionary containing diabetes risk assessment
    
    Returns:
        dict: Diet recommendations including foods to include, limit, and meal plans
    """
    try:
        # Calculate risk level
        risk_level = "low"
        if risk_assessment["probability"] >= 0.7:
            risk_level = "high"
        elif risk_assessment["probability"] >= 0.4:
            risk_level = "moderate"
        
        # Extract relevant metrics
        glucose = metrics.get("glucose", 0)
        if glucose is None:
            glucose = 0
            
        bmi = metrics.get("bmi", 0)
        if bmi is None:
            bmi = 0
            
        cholesterol = metrics.get("cholesterol", {}).get("total", 0)
        if cholesterol is None:
            cholesterol = 0
            
        triglycerides = metrics.get("triglycerides", 0)
        if triglycerides is None:
            triglycerides = 0
        
        # Initialize recommendations
        recommendations = {
            "overview": "",
            "include": [],
            "limit": [],
            "meal_plan": {
                "breakfast": [],
                "lunch": [],
                "dinner": [],
                "snacks": []
            },
            "additional_advice": ""
        }
        
        # Generate overview based on risk level
        if risk_level == "high":
            recommendations["overview"] = (
                "Your health metrics indicate a higher risk for diabetes. Following a strict "
                "diabetes-prevention diet is recommended. Focus on controlling carbohydrate intake, "
                "choosing foods with a low glycemic index, and maintaining consistent meal timing. "
                "Regular monitoring of blood glucose levels is advised."
            )
        elif risk_level == "moderate":
            recommendations["overview"] = (
                "Your health metrics show some risk factors for diabetes. A balanced diet with "
                "moderate carbohydrate control is recommended. Focus on whole foods, healthy fats, "
                "and regular meal patterns to maintain stable blood sugar levels."
            )
        else:
            recommendations["overview"] = (
                "Your health metrics indicate a lower risk for diabetes. Maintaining a healthy, "
                "balanced diet is recommended for continued wellness. Focus on whole foods, "
                "adequate protein, and plenty of vegetables and fruits."
            )
        
        # Foods to include based on risk level and metrics
        include_foods = []
        
        # Common healthy foods for all risk levels
        include_foods.extend([
            {
                "name": "Leafy Greens",
                "benefit": "Rich in vitamins, minerals, and antioxidants with minimal impact on blood sugar."
            },
            {
                "name": "Berries",
                "benefit": "Low in sugar compared to other fruits, high in fiber and antioxidants."
            },
            {
                "name": "Fatty Fish",
                "benefit": "High in omega-3 fatty acids which may improve insulin sensitivity."
            }
        ])
        
        # Add foods based on specific metrics
        if glucose > 100 or risk_level in ["moderate", "high"]:
            include_foods.extend([
                {
                    "name": "Cinnamon",
                    "benefit": "May help lower blood sugar levels and improve insulin sensitivity."
                },
                {
                    "name": "Apple Cider Vinegar",
                    "benefit": "May improve insulin sensitivity and lower blood sugar responses."
                }
            ])
        
        if cholesterol > 200 or triglycerides > 150:
            include_foods.extend([
                {
                    "name": "Oats",
                    "benefit": "Contains beta-glucan fiber which can help lower cholesterol levels."
                },
                {
                    "name": "Nuts",
                    "benefit": "Contains healthy fats that can help improve cholesterol profiles."
                }
            ])
        
        if bmi > 25:
            include_foods.extend([
                {
                    "name": "High-Fiber Vegetables",
                    "benefit": "Provides satiety with fewer calories, supporting weight management."
                },
                {
                    "name": "Lean Proteins",
                    "benefit": "Helps maintain muscle mass and increases fullness while supporting weight loss."
                }
            ])
        
        recommendations["include"] = include_foods
        
        # Foods to limit based on risk level and metrics
        limit_foods = []
        
        # Common foods to limit for all risk levels
        limit_foods.extend([
            {
                "name": "Sugary Beverages",
                "reason": "High in added sugars with minimal nutritional value, can cause blood sugar spikes."
            },
            {
                "name": "Processed Foods",
                "reason": "Often high in sodium, unhealthy fats, and added sugars."
            }
        ])
        
        # Add foods to limit based on specific metrics
        if glucose > 100 or risk_level in ["moderate", "high"]:
            limit_foods.extend([
                {
                    "name": "White Bread, Rice, and Pasta",
                    "reason": "High glycemic index foods that can cause rapid blood sugar spikes."
                },
                {
                    "name": "Fruit Juices",
                    "reason": "Even 100% fruit juice contains concentrated sugars without the fiber of whole fruits."
                }
            ])
        
        if cholesterol > 200 or triglycerides > 150:
            limit_foods.extend([
                {
                    "name": "Trans Fats",
                    "reason": "Can increase LDL (bad) cholesterol and decrease HDL (good) cholesterol."
                },
                {
                    "name": "High-Fat Dairy",
                    "reason": "Can contribute to elevated cholesterol levels."
                }
            ])
        
        if bmi > 25:
            limit_foods.extend([
                {
                    "name": "High-Calorie Snacks",
                    "reason": "Can contribute excess calories without providing adequate nutrition."
                },
                {
                    "name": "Alcohol",
                    "reason": "Contains empty calories and can stimulate appetite."
                }
            ])
        
        recommendations["limit"] = limit_foods
        
        # Create meal plans based on risk level
        if risk_level == "high":
            # High risk meal plan
            recommendations["meal_plan"]["breakfast"] = [
                {
                    "name": "Greek Yogurt Parfait",
                    "description": "Plain Greek yogurt with berries, chia seeds, and a small amount of nuts for protein and healthy fats."
                },
                {
                    "name": "Vegetable Omelet",
                    "description": "Eggs with spinach, bell peppers, and a small amount of cheese for a low-carb breakfast."
                }
            ]
            
            recommendations["meal_plan"]["lunch"] = [
                {
                    "name": "Salmon Salad",
                    "description": "Grilled salmon over mixed greens with olive oil and vinegar dressing."
                },
                {
                    "name": "Turkey and Vegetable Wrap",
                    "description": "Turkey wrapped in a low-carb tortilla with lettuce, cucumber, and avocado."
                }
            ]
            
            recommendations["meal_plan"]["dinner"] = [
                {
                    "name": "Baked Chicken with Roasted Vegetables",
                    "description": "Herb-seasoned chicken breast with non-starchy vegetables like broccoli and cauliflower."
                },
                {
                    "name": "Zucchini Noodles with Turkey Meatballs",
                    "description": "Spiralized zucchini with lean turkey meatballs and tomato sauce."
                }
            ]
            
            recommendations["meal_plan"]["snacks"] = [
                {
                    "name": "Celery with Almond Butter",
                    "description": "Provides fiber and healthy fats with minimal carbohydrates."
                },
                {
                    "name": "Hard-Boiled Egg",
                    "description": "Protein-rich snack that helps maintain satiety."
                }
            ]
        
        elif risk_level == "moderate":
            # Moderate risk meal plan
            recommendations["meal_plan"]["breakfast"] = [
                {
                    "name": "Overnight Oats",
                    "description": "Oats soaked in almond milk with cinnamon, berries, and a tablespoon of nuts."
                },
                {
                    "name": "Whole Grain Toast with Avocado",
                    "description": "Whole grain bread with smashed avocado and a poached egg."
                }
            ]
            
            recommendations["meal_plan"]["lunch"] = [
                {
                    "name": "Quinoa Bowl",
                    "description": "Quinoa with grilled chicken, mixed vegetables, and olive oil dressing."
                },
                {
                    "name": "Lentil Soup",
                    "description": "Lentil soup with vegetables and a small whole grain roll."
                }
            ]
            
            recommendations["meal_plan"]["dinner"] = [
                {
                    "name": "Baked Fish with Sweet Potato",
                    "description": "Baked white fish with herbs, a small sweet potato, and steamed greens."
                },
                {
                    "name": "Stir-Fry",
                    "description": "Tofu or chicken stir-fried with vegetables and a small portion of brown rice."
                }
            ]
            
            recommendations["meal_plan"]["snacks"] = [
                {
                    "name": "Apple with Cheese",
                    "description": "Combining fiber and protein helps stabilize blood sugar."
                },
                {
                    "name": "Hummus with Vegetable Sticks",
                    "description": "Provides protein, healthy fats, and fiber."
                }
            ]
        
        else:
            # Low risk meal plan
            recommendations["meal_plan"]["breakfast"] = [
                {
                    "name": "Smoothie Bowl",
                    "description": "Blend fruits, spinach, and protein powder, topped with nuts and seeds."
                },
                {
                    "name": "Whole Grain Cereal",
                    "description": "High-fiber cereal with low-fat milk and fresh fruit."
                }
            ]
            
            recommendations["meal_plan"]["lunch"] = [
                {
                    "name": "Mediterranean Salad",
                    "description": "Mixed greens with chickpeas, olives, feta, and olive oil dressing."
                },
                {
                    "name": "Whole Grain Sandwich",
                    "description": "Whole grain bread with lean protein, avocado, and plenty of vegetables."
                }
            ]
            
            recommendations["meal_plan"]["dinner"] = [
                {
                    "name": "Grilled Fish Tacos",
                    "description": "Grilled fish in corn tortillas with cabbage slaw and lime."
                },
                {
                    "name": "Vegetable and Bean Chili",
                    "description": "Bean-based chili with various vegetables and spices."
                }
            ]
            
            recommendations["meal_plan"]["snacks"] = [
                {
                    "name": "Yogurt with Fruit",
                    "description": "Good source of protein, calcium, and probiotics."
                },
                {
                    "name": "Trail Mix",
                    "description": "Small portion of nuts, seeds, and dried fruits provides energy and nutrients."
                }
            ]
        
        # Additional advice based on risk level
        if risk_level == "high":
            recommendations["additional_advice"] = (
                "Consider working with a registered dietitian for personalized meal planning. "
                "Monitor your carbohydrate intake carefully and aim for consistent carbohydrate consumption throughout the day. "
                "Be mindful of portion sizes and try to maintain regular meal timing. "
                "Include physical activity daily, ideally 30-60 minutes of moderate exercise. "
                "Stay well-hydrated with water rather than sugary beverages."
            )
        elif risk_level == "moderate":
            recommendations["additional_advice"] = (
                "Focus on portion control and balanced meals with protein, healthy fats, and complex carbohydrates. "
                "Aim for at least 150 minutes of moderate exercise per week. "
                "Be mindful of added sugars in foods and beverages. "
                "Consider keeping a food journal to identify patterns and areas for improvement."
            )
        else:
            recommendations["additional_advice"] = (
                "Maintain a balanced diet with plenty of fruits, vegetables, whole grains, and lean proteins. "
                "Stay physically active with at least 150 minutes of moderate exercise per week. "
                "Continue regular health check-ups to monitor your health metrics. "
                "Focus on overall healthy eating patterns rather than specific foods or nutrients."
            )
        
        return recommendations
        
    except Exception as e:
        st.error(f"Error generating diet recommendations: {str(e)}")
        return {
            "overview": "Could not generate personalized recommendations based on available data.",
            "include": [],
            "limit": [],
            "meal_plan": {"breakfast": [], "lunch": [], "dinner": [], "snacks": []},
            "additional_advice": "Please consult with a healthcare professional for dietary advice."
        }
