"""
Database module for DiagnoScan application.
Handles database connections and operations for storing and retrieving health report data.
"""

import os
import json
import datetime
from sqlalchemy import create_engine, Column, Integer, String, Float, Boolean, DateTime, Text, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship

# Get database URL from environment variable
DATABASE_URL = os.environ.get('DATABASE_URL')

if not DATABASE_URL:
    raise ValueError("DATABASE_URL environment variable not set. Please ensure database is properly configured.")

# Create SQLAlchemy engine
engine = create_engine(DATABASE_URL)

# Create declarative base
Base = declarative_base()

# Define User model
class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100))
    email = Column(String(100), unique=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Relationships
    reports = relationship("Report", back_populates="user", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<User(id={self.id}, name='{self.name}', email='{self.email}')>"

# Define Report model
class Report(Base):
    __tablename__ = 'reports'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    report_name = Column(String(255))
    uploaded_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    # PDF text content
    pdf_text = Column(Text)
    
    # Metrics as JSON
    metrics_json = Column(Text)
    
    # Risk assessment as JSON
    risk_json = Column(Text)
    
    # Relationships
    user = relationship("User", back_populates="reports")
    
    def __repr__(self):
        return f"<Report(id={self.id}, user_id={self.user_id}, report_name='{self.report_name}')>"
    
    @property
    def metrics(self):
        """Get metrics dictionary from JSON string"""
        if self.metrics_json:
            return json.loads(self.metrics_json)
        return {}
    
    @metrics.setter
    def metrics(self, metrics_dict):
        """Set metrics JSON string from dictionary"""
        if metrics_dict:
            self.metrics_json = json.dumps(metrics_dict)
        else:
            self.metrics_json = None
    
    @property
    def risk(self):
        """Get risk dictionary from JSON string"""
        if self.risk_json:
            return json.loads(self.risk_json)
        return {}
    
    @risk.setter
    def risk(self, risk_dict):
        """Set risk JSON string from dictionary"""
        if risk_dict:
            self.risk_json = json.dumps(risk_dict)
        else:
            self.risk_json = None

# Create all tables
Base.metadata.create_all(engine)

# Create session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    """Get database session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Database operations

def create_user(db, name, email):
    """Create a new user"""
    user = User(name=name, email=email)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user

def get_user_by_email(db, email):
    """Get user by email"""
    return db.query(User).filter(User.email == email).first()

def save_report(db, user_id, report_name, pdf_text, metrics, risk):
    """Save a new health report"""
    report = Report(
        user_id=user_id,
        report_name=report_name,
        pdf_text=pdf_text,
        metrics=metrics,
        risk=risk
    )
    db.add(report)
    db.commit()
    db.refresh(report)
    return report

def get_user_reports(db, user_id):
    """Get all reports for a user"""
    return db.query(Report).filter(Report.user_id == user_id).order_by(Report.uploaded_at.desc()).all()

def get_report_by_id(db, report_id):
    """Get report by ID"""
    return db.query(Report).filter(Report.id == report_id).first()