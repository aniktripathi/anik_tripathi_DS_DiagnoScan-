import io
import streamlit as st
import re

def validate_pdf(pdf_file):
    """
    Validate that the uploaded file is a valid PDF.
    
    Args:
        pdf_file: StreamlitUploadedFile object
    
    Returns:
        bool: True if the file is a valid PDF, False otherwise
    """
    try:
        # Check file size
        if pdf_file.size <= 0:
            return False
        
        # Check file type
        if not pdf_file.name.lower().endswith('.pdf'):
            return False
        
        # Check PDF header
        pdf_file.seek(0)
        header = pdf_file.read(5).decode('latin-1')
        pdf_file.seek(0)  # Reset file pointer
        
        return header.startswith('%PDF-')
    
    except Exception as e:
        st.error(f"Error validating PDF: {str(e)}")
        return False

def get_health_status_description(metrics, risk):
    """
    Generate a descriptive text about the patient's health status
    based on their metrics and risk assessment.
    
    Args:
        metrics: Dictionary containing health metrics
        risk: Dictionary containing diabetes risk assessment
    
    Returns:
        str: Descriptive text about health status
    """
    # Initialize description
    description = ""
    
    # Get risk level
    risk_probability = risk.get("probability", 0)
    if risk_probability < 0.4:
        risk_level = "low"
    elif risk_probability < 0.7:
        risk_level = "moderate"
    else:
        risk_level = "high"
    
    # Extract key standard metrics
    glucose = metrics.get("glucose")
    bmi = metrics.get("bmi")
    systolic = metrics.get("blood_pressure", {}).get("systolic")
    diastolic = metrics.get("blood_pressure", {}).get("diastolic")
    total_cholesterol = metrics.get("cholesterol", {}).get("total")
    hdl = metrics.get("cholesterol", {}).get("hdl")
    ldl = metrics.get("cholesterol", {}).get("ldl")
    triglycerides = metrics.get("triglycerides")
    hba1c = metrics.get("hba1c")
    
    # Extract additional lipid metrics
    vldl = metrics.get("vldl")
    non_hdl = metrics.get("non_hdl")
    apob = metrics.get("apob")
    apoa1 = metrics.get("apoa1")
    lipid_ratio = metrics.get("lipid_ratio")
    
    # Generate overall assessment based on risk level
    if risk_level == "high":
        description += (
            "Your health metrics indicate a **high risk** for diabetes. This means "
            "you should take immediate steps to improve your health metrics and "
            "consult with a healthcare provider for further evaluation and advice. "
        )
    elif risk_level == "moderate":
        description += (
            "Your health metrics indicate a **moderate risk** for diabetes. While not immediately "
            "concerning, it's important to make lifestyle adjustments to prevent progression "
            "to higher risk status. Regular check-ups are recommended. "
        )
    else:
        description += (
            "Your health metrics indicate a **low risk** for diabetes. Continue maintaining "
            "your healthy lifestyle habits. Regular check-ups are still important for "
            "preventive healthcare. "
        )
    
    # Add specific descriptions based on individual metrics
    description += "\n\n**Individual Health Metrics Analysis:**\n\n"
    
    # Check if we have any standard metrics
    has_standard_metrics = any(m is not None for m in [glucose, bmi, systolic, diastolic, total_cholesterol, hdl, ldl, triglycerides, hba1c])
    
    # Check if we have additional lipid metrics
    has_lipid_metrics = any(m is not None for m in [vldl, non_hdl, apob, apoa1, lipid_ratio])
    
    # If no standard metrics but we have lipid metrics
    if not has_standard_metrics and has_lipid_metrics:
        description += "- Your report primarily contains lipid profile metrics, which are important indicators of cardiovascular health.\n\n"
    
    # Standard Metrics Analysis
    
    # Glucose
    if glucose is not None:
        if glucose < 70:
            description += "- **Blood Glucose**: Your fasting glucose level is below the normal range, which may indicate hypoglycemia.\n"
        elif glucose < 100:
            description += "- **Blood Glucose**: Your fasting glucose level is within the normal range.\n"
        elif glucose < 126:
            description += "- **Blood Glucose**: Your fasting glucose level indicates prediabetes. Lifestyle modifications are recommended.\n"
        else:
            description += "- **Blood Glucose**: Your fasting glucose level is elevated, suggesting possible diabetes. Medical consultation is advised.\n"
    
    # HbA1c
    if hba1c is not None:
        if hba1c < 5.7:
            description += "- **HbA1c**: Your HbA1c is within the normal range.\n"
        elif hba1c < 6.5:
            description += "- **HbA1c**: Your HbA1c indicates prediabetes. This reflects your average blood sugar over the past 2-3 months.\n"
        else:
            description += "- **HbA1c**: Your HbA1c is elevated, suggesting diabetes. This reflects your average blood sugar over the past 2-3 months.\n"
    
    # Blood Pressure
    if systolic is not None and diastolic is not None:
        if systolic < 120 and diastolic < 80:
            description += "- **Blood Pressure**: Your blood pressure is within the normal range.\n"
        elif systolic < 130 and diastolic < 80:
            description += "- **Blood Pressure**: Your blood pressure is elevated, but not yet hypertensive.\n"
        elif systolic < 140 or diastolic < 90:
            description += "- **Blood Pressure**: Your blood pressure indicates Stage 1 hypertension.\n"
        else:
            description += "- **Blood Pressure**: Your blood pressure indicates Stage 2 hypertension. Medical attention is recommended.\n"
    
    # BMI
    if bmi is not None:
        if bmi < 18.5:
            description += "- **BMI**: Your BMI indicates you are underweight. Focus on nutritious foods to reach a healthy weight.\n"
        elif bmi < 25:
            description += "- **BMI**: Your BMI is within the healthy range.\n"
        elif bmi < 30:
            description += "- **BMI**: Your BMI indicates overweight status, which can contribute to diabetes risk.\n"
        else:
            description += "- **BMI**: Your BMI indicates obesity, which significantly increases diabetes risk. Weight management is recommended.\n"
    
    # Cholesterol
    if total_cholesterol is not None:
        if total_cholesterol < 200:
            description += "- **Total Cholesterol**: Your total cholesterol is within the desirable range.\n"
        elif total_cholesterol < 240:
            description += "- **Total Cholesterol**: Your total cholesterol is borderline high.\n"
        else:
            description += "- **Total Cholesterol**: Your total cholesterol is high, which increases cardiovascular risk.\n"
    
    # HDL
    if hdl is not None:
        if hdl >= 60:
            description += "- **HDL Cholesterol**: Your HDL (good) cholesterol is optimal, providing protective cardiovascular benefits.\n"
        elif hdl >= 40:
            description += "- **HDL Cholesterol**: Your HDL (good) cholesterol is acceptable.\n"
        else:
            description += "- **HDL Cholesterol**: Your HDL (good) cholesterol is low, which increases cardiovascular risk.\n"
    
    # LDL
    if ldl is not None:
        if ldl < 100:
            description += "- **LDL Cholesterol**: Your LDL (bad) cholesterol is optimal.\n"
        elif ldl < 130:
            description += "- **LDL Cholesterol**: Your LDL (bad) cholesterol is near optimal.\n"
        elif ldl < 160:
            description += "- **LDL Cholesterol**: Your LDL (bad) cholesterol is borderline high.\n"
        else:
            description += "- **LDL Cholesterol**: Your LDL (bad) cholesterol is high, increasing cardiovascular risk.\n"
    
    # Triglycerides
    if triglycerides is not None:
        if triglycerides < 150:
            description += "- **Triglycerides**: Your triglyceride levels are within the normal range.\n"
        elif triglycerides < 200:
            description += "- **Triglycerides**: Your triglyceride levels are borderline high.\n"
        else:
            description += "- **Triglycerides**: Your triglyceride levels are elevated, which can contribute to insulin resistance.\n"
    
    # Additional Lipid Metrics Analysis
    if has_lipid_metrics:
        description += "\n**Additional Lipid Profile Analysis:**\n\n"
        
        # VLDL
        if vldl is not None:
            if vldl < 30:
                description += "- **VLDL Cholesterol**: Your VLDL cholesterol is within the normal range.\n"
            else:
                description += "- **VLDL Cholesterol**: Your VLDL cholesterol is elevated, which may increase risk of cardiovascular disease.\n"
        
        # Non-HDL
        if non_hdl is not None:
            if non_hdl < 130:
                description += "- **Non-HDL Cholesterol**: Your non-HDL cholesterol is within the target range.\n"
            elif non_hdl < 160:
                description += "- **Non-HDL Cholesterol**: Your non-HDL cholesterol is slightly elevated.\n"
            else:
                description += "- **Non-HDL Cholesterol**: Your non-HDL cholesterol is high, indicating increased cardiovascular risk.\n"
        
        # ApoB
        if apob is not None:
            if apob < 100:
                description += "- **Apolipoprotein B**: Your ApoB is within the desirable range.\n"
            else:
                description += "- **Apolipoprotein B**: Your ApoB is elevated, indicating increased risk for atherosclerosis.\n"
        
        # ApoA1
        if apoa1 is not None:
            if apoa1 >= 125:
                description += "- **Apolipoprotein A1**: Your ApoA1 is optimal, which is associated with lower cardiovascular risk.\n"
            else:
                description += "- **Apolipoprotein A1**: Your ApoA1 is below optimal levels, which may indicate increased cardiovascular risk.\n"
        
        # Lipid Ratio (Total Cholesterol/HDL)
        if lipid_ratio is not None:
            if lipid_ratio < 3.5:
                description += "- **Cholesterol Ratio**: Your TC/HDL ratio is optimal, indicating a favorable lipid profile.\n"
            elif lipid_ratio < 5:
                description += "- **Cholesterol Ratio**: Your TC/HDL ratio is acceptable.\n"
            else:
                description += "- **Cholesterol Ratio**: Your TC/HDL ratio is elevated, indicating increased cardiovascular risk.\n"
    
    # Add a recommendation section
    description += "\n**Recommendations Based on Your Health Profile:**\n\n"
    
    if risk_level == "high":
        description += (
            "1. Consult with a healthcare provider promptly for comprehensive diabetes assessment and management plan.\n"
            "2. Consider blood glucose monitoring to track your levels regularly.\n"
            "3. Follow a structured diet plan focused on controlling carbohydrates and sugar intake.\n"
            "4. Engage in regular physical activity (at least 150 minutes per week) under medical guidance.\n"
            "5. Monitor your health metrics closely with regular check-ups.\n"
        )
    elif risk_level == "moderate":
        description += (
            "1. Schedule a follow-up appointment with a healthcare provider to discuss your diabetes risk.\n"
            "2. Implement dietary changes to improve blood sugar regulation.\n"
            "3. Begin a regular exercise routine of at least 150 minutes per week.\n"
            "4. Consider more frequent health check-ups (every 6 months) to monitor your metrics.\n"
            "5. Learn about diabetes symptoms so you can recognize early warning signs.\n"
        )
    else:
        description += (
            "1. Maintain your current healthy habits and regular check-ups.\n"
            "2. Continue eating a balanced diet rich in vegetables, lean proteins, and whole grains.\n"
            "3. Stay physically active with at least 150 minutes of moderate exercise per week.\n"
            "4. Conduct annual health screenings to ensure your metrics remain in healthy ranges.\n"
        )
    
    return description
