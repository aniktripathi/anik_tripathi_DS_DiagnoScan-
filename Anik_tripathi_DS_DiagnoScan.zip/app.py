import streamlit as st
import pandas as pd
import time
import datetime
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from pdf_processor import extract_text_from_pdf, extract_health_metrics
from diabetes_predictor import predict_diabetes_risk, evaluate_model
from diet_recommendations import get_diet_recommendations
from data_visualizer import (
    create_blood_metrics_chart,
    create_risk_gauge,
    create_health_trends
)
from utils import get_health_status_description, validate_pdf
from database import SessionLocal, create_user, get_user_by_email, save_report, get_user_reports, get_report_by_id

# Page configuration
st.set_page_config(
    page_title="DiagnoScan - Health Report Analysis",
    page_icon="🏥",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state variables if they don't exist
if 'pdf_text' not in st.session_state:
    st.session_state.pdf_text = None
if 'health_metrics' not in st.session_state:
    st.session_state.health_metrics = None
if 'diabetes_risk' not in st.session_state:
    st.session_state.diabetes_risk = None
if 'diet_recommendations' not in st.session_state:
    st.session_state.diet_recommendations = None
if 'current_page' not in st.session_state:
    st.session_state.current_page = "upload"
# Add reports page
if 'reports_page' not in st.session_state:
    st.session_state.reports_page = False
if 'user_id' not in st.session_state:
    st.session_state.user_id = None
if 'user_email' not in st.session_state:
    st.session_state.user_email = None
if 'user_name' not in st.session_state:
    st.session_state.user_name = None
if 'report_history' not in st.session_state:
    st.session_state.report_history = []
if 'current_report_id' not in st.session_state:
    st.session_state.current_report_id = None

# Header
st.title("DiagnoScan")
st.markdown("### Health Report Analysis & Diabetes Risk Assessment")

# Function to save current report to database
def save_current_report():
    if st.session_state.user_id and st.session_state.pdf_text and st.session_state.health_metrics and st.session_state.diabetes_risk:
        # Create a database session
        db = SessionLocal()
        try:
            # Generate a report name based on date
            report_name = f"Health Report - {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}"
            
            # Save report to database
            report = save_report(
                db, 
                st.session_state.user_id, 
                report_name, 
                st.session_state.pdf_text, 
                st.session_state.health_metrics, 
                st.session_state.diabetes_risk
            )
            
            # Update current report ID
            st.session_state.current_report_id = report.id
            
            # Update report history
            st.session_state.report_history = get_user_reports(db, st.session_state.user_id)
            
            return True
        except Exception as e:
            st.error(f"Error saving report: {str(e)}")
            return False
        finally:
            db.close()
    return False

# Function to load report from database
def load_report(report_id):
    if report_id:
        # Create a database session
        db = SessionLocal()
        try:
            # Get report from database
            report = get_report_by_id(db, report_id)
            
            if report:
                # Load report data into session state
                st.session_state.pdf_text = report.pdf_text
                st.session_state.health_metrics = report.metrics
                st.session_state.diabetes_risk = report.risk
                
                # Generate diet recommendations based on loaded data
                st.session_state.diet_recommendations = get_diet_recommendations(
                    st.session_state.health_metrics, 
                    st.session_state.diabetes_risk
                )
                
                # Update current report ID
                st.session_state.current_report_id = report.id
                
                return True
        except Exception as e:
            st.error(f"Error loading report: {str(e)}")
            return False
        finally:
            db.close()
    return False

# Sidebar for navigation
with st.sidebar:
    st.markdown("## 🏥 DiagnoScan")
    
    # User Authentication Section
    if not st.session_state.user_id:
        st.subheader("User Account")
        
        # Login/Registration form
        with st.form("auth_form"):
            email = st.text_input("Email")
            name = st.text_input("Name")
            submit = st.form_submit_button("Login / Register")
            
            if submit and email and name:
                # Create a database session
                db = SessionLocal()
                try:
                    # Check if user exists
                    user = get_user_by_email(db, email)
                    
                    if not user:
                        # Create new user
                        user = create_user(db, name, email)
                        st.success(f"New account created for {name}")
                    else:
                        st.success(f"Welcome back, {user.name}!")
                    
                    # Set user in session state
                    st.session_state.user_id = user.id
                    st.session_state.user_email = user.email
                    st.session_state.user_name = user.name
                    
                    # Load user's report history
                    st.session_state.report_history = get_user_reports(db, user.id)
                    
                    st.rerun()
                except Exception as e:
                    st.error(f"Authentication error: {str(e)}")
                finally:
                    db.close()
    else:
        # Display user info
        st.info(f"Logged in as: {st.session_state.user_name}")
        
        # Report history
        if st.session_state.report_history:
            st.subheader("Report History")
            
            for i, report in enumerate(st.session_state.report_history):
                if st.button(f"{report.report_name}", key=f"report_{report.id}"):
                    if load_report(report.id):
                        st.session_state.current_page = "results"
                        st.rerun()
        
        # Logout button
        if st.button("Logout", use_container_width=True):
            # Clear user data
            st.session_state.user_id = None
            st.session_state.user_email = None
            st.session_state.user_name = None
            st.session_state.report_history = []
            st.session_state.current_report_id = None
            st.rerun()
    
    st.header("Navigation")
    
    if st.button("Upload Report", use_container_width=True, 
                 disabled=st.session_state.current_page=="upload"):
        st.session_state.current_page = "upload"
        st.rerun()
    
    if st.button("Analysis Results", use_container_width=True, 
                 disabled=st.session_state.health_metrics is None or st.session_state.current_page=="results"):
        st.session_state.current_page = "results"
        st.rerun()
    
    if st.button("Diet Recommendations", use_container_width=True, 
                 disabled=st.session_state.health_metrics is None or st.session_state.current_page=="diet"):
        st.session_state.current_page = "diet"
        st.rerun()
        
    # Model Evaluation button
    if st.button("Model Evaluation", use_container_width=True,
                disabled=st.session_state.current_page=="model_eval"):
        st.session_state.current_page = "model_eval"
        st.rerun()
    
    # Reports page button
    if st.session_state.user_id:
        if st.button("My Reports", use_container_width=True, 
                    disabled=st.session_state.current_page=="reports"):
            st.session_state.current_page = "reports"
            # Refresh report history
            db = SessionLocal()
            try:
                st.session_state.report_history = get_user_reports(db, st.session_state.user_id)
            finally:
                db.close()
            st.rerun()
    
    # Save Report button (only shown if user is logged in and has report data)
    if st.session_state.user_id and st.session_state.health_metrics is not None:
        if st.button("Save Report", use_container_width=True):
            if save_current_report():
                st.success("Report saved successfully!")
                time.sleep(1)
                st.rerun()
    
    if st.button("Clear Data", use_container_width=True):
        st.session_state.pdf_text = None
        st.session_state.health_metrics = None
        st.session_state.diabetes_risk = None
        st.session_state.diet_recommendations = None
        st.session_state.current_report_id = None
        st.session_state.current_page = "upload"
        st.rerun()
    
    st.markdown("---")
    st.markdown("### About DiagnoScan")
    st.info(
        "DiagnoScan analyzes your health report to assess diabetes risk "
        "and provide personalized health recommendations."
    )

# Upload Report Page
if st.session_state.current_page == "upload":
    st.header("Upload Your Health Report")
    
    st.markdown(
        "DiagnoScan analyzes your medical reports to provide insights about your health "
        "and assess diabetes risk factors. Please upload your health report in PDF format."
    )
    
    uploaded_file = st.file_uploader("Choose a PDF file", type=["pdf"])
    
    if uploaded_file:
        if validate_pdf(uploaded_file):
            with st.spinner("Processing your health report..."):
                # Extract text from PDF
                st.session_state.pdf_text = extract_text_from_pdf(uploaded_file)
                
                # Extract health metrics from the PDF text
                try:
                    st.session_state.health_metrics = extract_health_metrics(st.session_state.pdf_text)
                    
                    # Predict diabetes risk based on health metrics
                    st.session_state.diabetes_risk = predict_diabetes_risk(st.session_state.health_metrics)
                    
                    # Generate diet recommendations based on health metrics and risk
                    st.session_state.diet_recommendations = get_diet_recommendations(
                        st.session_state.health_metrics, 
                        st.session_state.diabetes_risk
                    )
                    
                    st.success("Report processed successfully!")
                    time.sleep(1)
                    st.session_state.current_page = "results"
                    st.rerun()
                except Exception as e:
                    st.error(f"Error processing the health report: {str(e)}")
                    st.markdown("""
                    Please ensure your report contains health metrics like:
                    - Standard metrics: glucose, blood pressure, cholesterol, etc.
                    - OR lipid profile metrics: HDL, LDL, VLDL, etc.
                    
                    DiagnoScan can analyze your report with either type of metrics.
                    """)
        else:
            st.error("The uploaded file appears to be an invalid or corrupt PDF. Please upload a valid health report.")
    
    # Sample metrics explanation
    with st.expander("What health metrics are analyzed?"):
        st.markdown("""
        DiagnoScan analyzes the following key health metrics:
        
        **Standard Health Metrics:**
        - **Glucose Levels**: Fasting blood sugar and HbA1c
        - **Blood Pressure**: Systolic and diastolic readings
        - **Cholesterol**: HDL, LDL, and total cholesterol
        - **Triglycerides**: Fat levels in the blood
        - **BMI**: Body Mass Index
        - **Age, Gender & Family History**: Demographic risk factors
        
        **Additional Lipid Profile Metrics:**
        - **VLDL**: Very low-density lipoprotein
        - **Non-HDL Cholesterol**: All non-HDL cholesterol 
        - **Apolipoproteins**: ApoB and ApoA1 proteins
        - **Lipid Ratios**: TC/HDL and other cholesterol ratios
        
        DiagnoScan can analyze your report with either set of metrics to assess your health status.
        """)

# Results Page
elif st.session_state.current_page == "results":
    st.header("Health Analysis Results")
    
    if st.session_state.health_metrics is not None:
        metrics = st.session_state.health_metrics
        risk = st.session_state.diabetes_risk
        
        # Display risk level
        col1, col2 = st.columns([1, 2])
        
        with col1:
            st.subheader("Diabetes Risk Assessment")
            st.plotly_chart(create_risk_gauge(risk["probability"]), use_container_width=True)
            
            risk_level = "Low" if risk["probability"] < 0.4 else "Moderate" if risk["probability"] < 0.7 else "High"
            st.markdown(f"### Risk Level: {risk_level}")
            
            st.markdown(f"**Risk Score:** {risk['probability']:.2f}")
            st.markdown(f"**Confidence:** {risk['confidence']:.2f}")
        
        with col2:
            st.subheader("Key Health Indicators")
            blood_chart = create_blood_metrics_chart(metrics)
            st.plotly_chart(blood_chart, use_container_width=True)
        
        # Health status description
        st.subheader("Health Status")
        health_description = get_health_status_description(metrics, risk)
        st.markdown(health_description)
        
        # Key factors
        st.subheader("Key Risk Factors")
        
        # Display the feature importances
        risk_factors = risk.get("feature_importance", {})
        
        if risk_factors:
            factors_df = pd.DataFrame({
                "Factor": list(risk_factors.keys()),
                "Importance": list(risk_factors.values())
            }).sort_values("Importance", ascending=False)
            
            st.bar_chart(factors_df.set_index("Factor"))
            
            st.markdown("### What These Factors Mean")
            for factor, importance in risk_factors.items():
                if importance > 0.1:  # Only show significant factors
                    st.markdown(f"**{factor}**: {get_factor_description(factor)}")
        else:
            st.info("Risk factor analysis is not available for this report.")
        
        # Health trends visualization
        st.subheader("Health Metrics Comparison")
        st.plotly_chart(create_health_trends(metrics), use_container_width=True)

    else:
        st.warning("No health report data found. Please upload your health report first.")
        st.session_state.current_page = "upload"
        st.rerun()

# Reports Page
elif st.session_state.current_page == "reports":
    st.header("My Health Reports")
    
    if st.session_state.user_id and st.session_state.report_history:
        # Display all user reports in a table
        report_data = []
        for report in st.session_state.report_history:
            # Extract uploaded date from report
            uploaded_at = report.uploaded_at.strftime("%Y-%m-%d %H:%M")
            
            # Extract risk level if available
            risk_level = "Unknown"
            if report.risk and "probability" in report.risk:
                risk_prob = report.risk["probability"]
                risk_level = "Low" if risk_prob < 0.4 else "Moderate" if risk_prob < 0.7 else "High"
            
            # Add to report data
            report_data.append({
                "ID": report.id,
                "Name": report.report_name,
                "Date": uploaded_at,
                "Risk Level": risk_level
            })
        
        # Create DataFrame for table display
        reports_df = pd.DataFrame(report_data)
        
        # Display table with selection
        st.subheader("Select a report to view")
        selected_indices = st.dataframe(
            reports_df, 
            column_config={
                "ID": st.column_config.Column(
                    "ID",
                    width="small",
                ),
                "Name": st.column_config.Column(
                    "Report Name", 
                    width="medium",
                ),
                "Date": st.column_config.Column(
                    "Date", 
                    width="small",
                ),
                "Risk Level": st.column_config.Column(
                    "Risk Level", 
                    width="small",
                ),
            },
            use_container_width=True,
            hide_index=True
        )
        
        # Allow selection of report
        selected_report_id = st.selectbox(
            "Choose a report to view:", 
            options=[report["ID"] for report in report_data],
            format_func=lambda x: next((r["Name"] for r in report_data if r["ID"] == x), "")
        )
        
        if st.button("View Selected Report"):
            if load_report(selected_report_id):
                st.success("Report loaded successfully!")
                time.sleep(1)
                st.session_state.current_page = "results"
                st.rerun()
        
    else:
        if not st.session_state.user_id:
            st.warning("Please log in to view your report history.")
        else:
            st.info("You don't have any saved reports yet. Upload a health report and save it to see it here.")
    
# Diet Recommendations Page
elif st.session_state.current_page == "diet":
    st.header("Personalized Diet Recommendations")
    
    if st.session_state.diet_recommendations is not None:
        recommendations = st.session_state.diet_recommendations
        
        st.subheader("Dietary Guidelines")
        st.markdown(recommendations["overview"])
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("Foods to Include")
            for food in recommendations["include"]:
                st.markdown(f"- **{food['name']}**: {food['benefit']}")
        
        with col2:
            st.subheader("Foods to Limit")
            for food in recommendations["limit"]:
                st.markdown(f"- **{food['name']}**: {food['reason']}")
        
        st.subheader("Sample Meal Plan")
        
        tabs = st.tabs(["Breakfast", "Lunch", "Dinner", "Snacks"])
        
        with tabs[0]:
            for meal in recommendations["meal_plan"]["breakfast"]:
                st.markdown(f"- **{meal['name']}**: {meal['description']}")
        
        with tabs[1]:
            for meal in recommendations["meal_plan"]["lunch"]:
                st.markdown(f"- **{meal['name']}**: {meal['description']}")
        
        with tabs[2]:
            for meal in recommendations["meal_plan"]["dinner"]:
                st.markdown(f"- **{meal['name']}**: {meal['description']}")
        
        with tabs[3]:
            for meal in recommendations["meal_plan"]["snacks"]:
                st.markdown(f"- **{meal['name']}**: {meal['description']}")
        
        st.subheader("Additional Recommendations")
        st.markdown(recommendations["additional_advice"])
        
        st.info(
            "These recommendations are based on your health metrics and risk assessment. "
            "Always consult with a healthcare professional before making significant changes to your diet."
        )
    else:
        st.warning("No health report data found. Please upload your health report first.")
        st.session_state.current_page = "upload"
        st.rerun()

# Helper function to describe risk factors
def get_factor_description(factor):
    descriptions = {
        "Glucose": "High blood glucose levels are directly linked to diabetes. Consistently elevated levels indicate your body's inability to properly process sugar.",
        "BMI": "Body Mass Index relates to body fat. Higher BMI increases diabetes risk due to insulin resistance in body tissues.",
        "Age": "Diabetes risk increases with age, particularly after 45, due to decreasing pancreatic function and insulin sensitivity.",
        "Blood Pressure": "Hypertension and diabetes often occur together. High blood pressure can damage blood vessels and affect insulin delivery.",
        "Cholesterol": "Abnormal cholesterol levels, especially high LDL and low HDL, increase cardiovascular risk and are associated with diabetes.",
        "Triglycerides": "Elevated triglycerides often indicate insulin resistance, a key factor in type 2 diabetes development.",
        "Family History": "Genetic factors significantly influence diabetes risk. Having first-degree relatives with diabetes increases your risk.",
        "HbA1c": "This reflects your average blood glucose over 2-3 months. Higher levels indicate consistent hyperglycemia.",
        "HDL": "Low levels of 'good' cholesterol are associated with insulin resistance and increased diabetes risk.",
        "LDL": "Elevated 'bad' cholesterol increases cardiovascular complications risk for diabetic patients.",
        "Systolic BP": "The pressure in your arteries when your heart beats. High systolic pressure is linked to cardiovascular issues that increase diabetes risk.",
        "Diastolic BP": "The pressure in your arteries between heartbeats. Elevated diastolic pressure contributes to overall hypertension risk.",
        "Total Cholesterol": "The combined measure of different types of cholesterol in your blood. Elevated levels can indicate increased cardiovascular risk.",
        "VLDL": "Very low-density lipoprotein transports triglycerides in the blood. High VLDL can contribute to plaque buildup in arteries.",
        "Non-HDL": "All cholesterol that is not HDL. Higher levels indicate increased risk for atherosclerosis.",
        "ApoB": "A protein found in cholesterol particles that contributes to plaque formation. High levels often indicate increased cardiovascular risk."
    }
    
    return descriptions.get(factor, "This factor contributes to your overall diabetes risk assessment.")

st.markdown("""
<style>
    .reportview-container {
        margin-top: -2em;
    }
    .stDeployButton {
        display:none
    }
    footer {visibility: hidden;}
</style>
""", unsafe_allow_html=True)
