import { db } from "./index";
import * as schema from "@shared/schema";

async function seed() {
  try {
    console.log("Starting seed process...");

    // Seed recommendations data for normal status
    const normalRecommendations = {
      diet: {
        include: [
          "Whole grains (brown rice, oats, quinoa)",
          "Lean proteins (chicken, fish, tofu)",
          "Variety of fruits and vegetables",
          "Low-fat dairy products"
        ],
        avoid: [
          "Excessive sugar and sweets",
          "Processed foods high in sodium",
          "Trans fats and fried foods",
          "Excessive alcohol consumption"
        ]
      },
      exercise: [
        {
          name: "Walking",
          duration: "30 minutes",
          frequency: "daily",
          icon: "walking"
        },
        {
          name: "Cycling",
          duration: "20-30 minutes",
          frequency: "3 times weekly",
          icon: "bicycle"
        },
        {
          name: "Recreational sports",
          duration: "45-60 minutes",
          frequency: "2-3 times weekly",
          icon: "basketball-ball"
        }
      ],
      lifestyle: [
        {
          name: "Regular Meal Timing",
          description: "Maintain consistent meal schedule",
          icon: "clock"
        },
        {
          name: "Quality Sleep",
          description: "7-8 hours nightly",
          icon: "moon"
        },
        {
          name: "Hydration",
          description: "8-10 glasses of water daily",
          icon: "tint"
        }
      ]
    };

    // Seed recommendations data for pre-diabetic status
    const preDiabeticRecommendations = {
      diet: {
        include: [
          "High-fiber foods (whole grains, legumes)",
          "Lean proteins (fish, skinless poultry)",
          "Non-starchy vegetables",
          "Healthy fats (avocados, nuts, olive oil)"
        ],
        avoid: [
          "Refined carbohydrates (white bread, pastries)",
          "Sugary beverages and foods",
          "Processed snacks and fast food",
          "High-sodium processed meats"
        ]
      },
      exercise: [
        {
          name: "Walking",
          duration: "30 minutes",
          frequency: "daily",
          icon: "walking"
        },
        {
          name: "Cycling",
          duration: "20-30 minutes",
          frequency: "3 times weekly",
          icon: "bicycle"
        },
        {
          name: "Strength Training",
          duration: "15-20 minutes",
          frequency: "2-3 times weekly",
          icon: "dumbbell"
        },
        {
          name: "Swimming",
          duration: "20-30 minutes",
          frequency: "2 times weekly",
          icon: "swimming-pool"
        }
      ],
      lifestyle: [
        {
          name: "Regular Meal Timing",
          description: "Maintain consistent meal schedule",
          icon: "clock"
        },
        {
          name: "Quality Sleep",
          description: "7-8 hours nightly",
          icon: "moon"
        },
        {
          name: "Hydration",
          description: "8-10 glasses of water daily",
          icon: "tint"
        },
        {
          name: "Stress Management",
          description: "Practice mindfulness and relaxation techniques",
          icon: "peace"
        }
      ]
    };

    // Seed recommendations data for diabetic status
    const diabeticRecommendations = {
      diet: {
        include: [
          "Complex carbohydrates (whole grains, legumes)",
          "Fiber-rich foods (vegetables, fruits with skin)",
          "Plant-based proteins (beans, lentils)",
          "Omega-3 rich foods (fatty fish, flaxseeds)"
        ],
        avoid: [
          "Simple sugars and sweets",
          "White bread, white rice, regular pasta",
          "Fried foods and saturated fats",
          "Fruit juices and sweetened beverages"
        ]
      },
      exercise: [
        {
          name: "Walking",
          duration: "30 minutes",
          frequency: "daily",
          icon: "walking"
        },
        {
          name: "Cycling",
          duration: "20-30 minutes",
          frequency: "3 times weekly",
          icon: "bicycle"
        },
        {
          name: "Strength Training",
          duration: "15-20 minutes",
          frequency: "2-3 times weekly",
          icon: "dumbbell"
        },
        {
          name: "Low-impact cardio",
          duration: "15-20 minutes",
          frequency: "3-4 times weekly",
          icon: "heartbeat"
        },
        {
          name: "Yoga",
          duration: "20 minutes",
          frequency: "2-3 times weekly",
          icon: "om"
        }
      ],
      lifestyle: [
        {
          name: "Regular Meal Timing",
          description: "Maintain consistent meal schedule",
          icon: "clock"
        },
        {
          name: "Quality Sleep",
          description: "7-8 hours nightly",
          icon: "moon"
        },
        {
          name: "Hydration",
          description: "8-10 glasses of water daily",
          icon: "tint"
        },
        {
          name: "Stress Management",
          description: "Practice mindfulness and relaxation techniques",
          icon: "peace"
        },
        {
          name: "Avoid Smoking",
          description: "Quit smoking and avoid second-hand smoke",
          icon: "ban"
        },
        {
          name: "Monitor Blood Sugar",
          description: "Check blood glucose levels regularly",
          icon: "microscope"
        }
      ]
    };

    // Seed sample blood reports
    const sampleReports = [
      {
        haemoglobin: 13.2,
        fastingGlucose: 85,
        randomGlucose: 110,
        hba1c: 5.2,
        age: 35,
        bmi: 22.5,
        isDiabetic: false,
        diabetesStatus: "Normal",
        confidenceScore: 88.5,
      },
      {
        haemoglobin: 12.5,
        fastingGlucose: 115,
        randomGlucose: 135,
        hba1c: 6.1,
        age: 45,
        bmi: 26.3,
        isDiabetic: true,
        diabetesStatus: "Pre-diabetic",
        confidenceScore: 78.2,
      },
      {
        haemoglobin: 11.8,
        fastingGlucose: 140,
        randomGlucose: 180,
        hba1c: 7.2,
        age: 58,
        bmi: 29.7,
        isDiabetic: true,
        diabetesStatus: "Diabetic",
        confidenceScore: 92.4,
      }
    ];

    // Check if there are any existing reports
    const existingReports = await db.query.bloodReports.findMany({
      limit: 1
    });

    // Only seed if no reports exist
    if (existingReports.length === 0) {
      console.log("Seeding sample blood reports...");
      
      for (const reportData of sampleReports) {
        const [report] = await db.insert(schema.bloodReports).values(reportData).returning({
          id: schema.bloodReports.id
        });
        
        let recommendations;
        if (reportData.diabetesStatus === "Normal") {
          recommendations = normalRecommendations;
        } else if (reportData.diabetesStatus === "Pre-diabetic") {
          recommendations = preDiabeticRecommendations;
        } else {
          recommendations = diabeticRecommendations;
        }
        
        await db.insert(schema.recommendations).values({
          reportId: report.id,
          dietRecommendations: JSON.stringify(recommendations.diet),
          exerciseRecommendations: JSON.stringify(recommendations.exercise),
          lifestyleRecommendations: JSON.stringify(recommendations.lifestyle)
        });
      }
      
      console.log("Seed data inserted successfully!");
    } else {
      console.log("Database already contains reports, skipping seed process");
    }
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
