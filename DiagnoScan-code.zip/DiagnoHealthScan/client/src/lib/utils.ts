import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatNumber(value: number | undefined | null, decimals = 1): string {
  if (value === undefined || value === null) return "0";
  return value.toFixed(decimals);
}

export const normalRanges = {
  haemoglobin: { min: 12.0, max: 16.0 }, // g/dL
  fastingGlucose: { min: 70, max: 100 }, // mg/dL
  randomGlucose: { min: 70, max: 140 }, // mg/dL
  hba1c: { min: 4.0, max: 5.6 }, // %
  bmi: { min: 18.5, max: 24.9 }
};

export const preDiabeticRanges = {
  fastingGlucose: { min: 100, max: 125 }, // mg/dL
  randomGlucose: { min: 140, max: 200 }, // mg/dL
  hba1c: { min: 5.7, max: 6.4 } // %
};

export const diabeticRanges = {
  fastingGlucose: { min: 126, max: 500 }, // mg/dL
  randomGlucose: { min: 200, max: 500 }, // mg/dL
  hba1c: { min: 6.5, max: 15 } // %
};

export function getStatusClass(value: number, type: keyof typeof normalRanges): string {
  // Handle haemoglobin and BMI differently as they don't follow the same pattern
  if (type === 'haemoglobin') {
    if (value < normalRanges.haemoglobin.min) return 'status-diabetic';
    if (value > normalRanges.haemoglobin.max) return 'status-prediabetic';
    return 'status-normal';
  }
  
  if (type === 'bmi') {
    if (value < normalRanges.bmi.min) return 'status-prediabetic';
    if (value > normalRanges.bmi.max) return value > 30 ? 'status-diabetic' : 'status-prediabetic';
    return 'status-normal';
  }
  
  // For glucose and HbA1c values
  if (value <= normalRanges[type].max) return 'status-normal';
  if (preDiabeticRanges[type as keyof typeof preDiabeticRanges] && 
      value <= preDiabeticRanges[type as keyof typeof preDiabeticRanges].max) return 'status-prediabetic';
  return 'status-diabetic';
}

export function getStatusText(value: number, type: keyof typeof normalRanges): string {
  // Return status based on getStatusClass
  const statusClass = getStatusClass(value, type);
  if (statusClass === 'status-normal') return 'Normal';
  if (statusClass === 'status-prediabetic') return 'Elevated';
  return 'High';
}

export function parseJsonIfString<T>(value: string | T): T {
  if (typeof value === 'string') {
    try {
      return JSON.parse(value) as T;
    } catch (e) {
      console.error('Error parsing JSON string:', e);
      return {} as T;
    }
  }
  return value;
}

export function capitalizeFirstLetter(string: string): string {
  return string.charAt(0).toUpperCase() + string.slice(1);
}
