import { useState } from "react";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import HealthCharts from "@/components/health-charts";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { TrendChart } from "@/components/health-charts";

export default function Insights() {
  // Demo data for visualization purposes
  const [activeData, setActiveData] = useState({
    haemoglobin: 14.2,
    fastingGlucose: 110,
    randomGlucose: 140,
    hba1c: 5.8,
    age: 45,
    bmi: 26.5,
  });

  // Demo data sets that can be selected for comparison
  const dataSets = [
    {
      id: 1,
      name: "Current Profile",
      date: "May 1, 2025",
      data: {
        haemoglobin: 14.2,
        fastingGlucose: 110,
        randomGlucose: 140,
        hba1c: 5.8,
        age: 45,
        bmi: 26.5,
      },
    },
    {
      id: 2,
      name: "3 Months Ago",
      date: "Feb 1, 2025",
      data: {
        haemoglobin: 13.9,
        fastingGlucose: 115,
        randomGlucose: 145,
        hba1c: 6.0,
        age: 45,
        bmi: 27.2,
      },
    },
    {
      id: 3,
      name: "6 Months Ago",
      date: "Nov 1, 2024",
      data: {
        haemoglobin: 13.5,
        fastingGlucose: 125,
        randomGlucose: 160,
        hba1c: 6.2,
        age: 44,
        bmi: 28.1,
      },
    },
  ];

  // Health metrics with explanations
  const healthMetrics = [
    {
      name: "Fasting Glucose",
      value: activeData.fastingGlucose,
      unit: "mg/dL",
      description:
        "A blood sugar level measured after not eating for at least 8 hours. Normal range is 70-99 mg/dL.",
      status:
        activeData.fastingGlucose < 100
          ? "normal"
          : activeData.fastingGlucose < 126
          ? "prediabetic"
          : "diabetic",
    },
    {
      name: "HbA1c",
      value: activeData.hba1c,
      unit: "%",
      description:
        "Reflects your average blood sugar level over the past 2-3 months. Normal range is below 5.7%.",
      status:
        activeData.hba1c < 5.7
          ? "normal"
          : activeData.hba1c < 6.4
          ? "prediabetic"
          : "diabetic",
    },
    {
      name: "BMI",
      value: activeData.bmi,
      unit: "kg/m²",
      description:
        "Body Mass Index measures body fat based on height and weight. Normal range is 18.5-24.9.",
      status:
        activeData.bmi < 18.5
          ? "underweight"
          : activeData.bmi < 25
          ? "normal"
          : activeData.bmi < 30
          ? "overweight"
          : "obese",
    },
    {
      name: "Haemoglobin",
      value: activeData.haemoglobin,
      unit: "g/dL",
      description:
        "Measures the protein in red blood cells that carries oxygen. Normal range for adults is 12-17 g/dL.",
      status:
        activeData.haemoglobin < 12
          ? "low"
          : activeData.haemoglobin > 17
          ? "high"
          : "normal",
    },
  ];

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />

      <main className="flex-1">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          {/* Hero section */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-extrabold text-slate-900 dark:text-white sm:text-5xl sm:tracking-tight lg:text-6xl font-sans">
              Health Insights
            </h1>
            <p className="mt-5 max-w-xl mx-auto text-xl text-slate-500 dark:text-slate-300">
              Comprehensive visualization and analysis of your health metrics
            </p>
          </div>

          {/* Data selector */}
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-4">
              Select Health Data Profile
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {dataSets.map((dataset) => (
                <Card
                  key={dataset.id}
                  className={`cursor-pointer transition-all ${
                    activeData === dataset.data
                      ? "border-primary-500 dark:border-primary-400 ring-2 ring-primary-500/30"
                      : "hover:border-slate-300 dark:hover:border-slate-600"
                  }`}
                  onClick={() => setActiveData(dataset.data)}
                >
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="font-medium text-slate-900 dark:text-white">
                          {dataset.name}
                        </h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">
                          {dataset.date}
                        </p>
                      </div>
                      {activeData === dataset.data && (
                        <Badge variant="outline" className="bg-primary-50 dark:bg-primary-900/20 border-primary-200 dark:border-primary-800 text-primary-700 dark:text-primary-300">
                          Selected
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Health Charts */}
          <HealthCharts bloodData={activeData} />

          {/* Historical trend */}
          <div className="mt-12 mb-12">
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-6 font-sans text-center">
              Historical Health Trends
            </h3>
            <div className="bg-white dark:bg-slate-700 shadow rounded-lg overflow-hidden">
              <div className="px-4 py-5 sm:p-6">
                <div className="h-80">
                  <TrendChart />
                </div>
                <div className="mt-2 text-sm text-slate-500 dark:text-slate-300 text-center">
                  Your blood glucose and HbA1c trends over the past 6 months
                </div>
              </div>
            </div>
          </div>

          {/* Health metrics */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-6">
              Key Health Indicators
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {healthMetrics.map((metric) => (
                <Card key={metric.name}>
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-lg font-medium text-slate-900 dark:text-white">
                          {metric.name}
                        </h3>
                        <div className="mt-1 text-3xl font-semibold">
                          {metric.value}{" "}
                          <span className="text-sm font-normal text-slate-500 dark:text-slate-400">
                            {metric.unit}
                          </span>
                        </div>
                      </div>
                      <Badge
                        className={
                          metric.status === "normal"
                            ? "bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200"
                            : metric.status === "prediabetic" || metric.status === "overweight"
                            ? "bg-amber-100 dark:bg-amber-900 text-amber-800 dark:text-amber-200"
                            : "bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200"
                        }
                      >
                        {metric.status.charAt(0).toUpperCase() + metric.status.slice(1)}
                      </Badge>
                    </div>
                    <p className="mt-4 text-slate-500 dark:text-slate-300">
                      {metric.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Risk factors */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-6">
              Diabetes Risk Analysis
            </h2>
            <Card>
              <CardContent className="p-6">
                <Tabs defaultValue="factors">
                  <TabsList className="mb-6">
                    <TabsTrigger value="factors">Risk Factors</TabsTrigger>
                    <TabsTrigger value="prevention">Prevention</TabsTrigger>
                    <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
                  </TabsList>
                  <TabsContent value="factors">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-3">
                          Non-modifiable Risk Factors
                        </h3>
                        <ul className="list-disc pl-5 text-slate-500 dark:text-slate-300 space-y-2">
                          <li>Family history of diabetes</li>
                          <li>Age (risk increases after 45)</li>
                          <li>Ethnicity (higher risk in certain populations)</li>
                          <li>History of gestational diabetes</li>
                          <li>Polycystic ovary syndrome</li>
                        </ul>
                      </div>
                      <div>
                        <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-3">
                          Modifiable Risk Factors
                        </h3>
                        <ul className="list-disc pl-5 text-slate-500 dark:text-slate-300 space-y-2">
                          <li>Being overweight or obese</li>
                          <li>Physical inactivity</li>
                          <li>High blood pressure</li>
                          <li>Abnormal cholesterol levels</li>
                          <li>Smoking</li>
                          <li>High sugar and processed food consumption</li>
                        </ul>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="prevention">
                    <div>
                      <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-3">
                        Diabetes Prevention Strategies
                      </h3>
                      <ul className="list-disc pl-5 text-slate-500 dark:text-slate-300 space-y-2">
                        <li>Maintain a healthy weight or lose weight if overweight</li>
                        <li>Engage in regular physical activity (150+ minutes/week)</li>
                        <li>Follow a balanced diet rich in fruits, vegetables, and whole grains</li>
                        <li>Limit refined carbohydrates and processed foods</li>
                        <li>Monitor blood pressure and cholesterol levels</li>
                        <li>Quit smoking and limit alcohol consumption</li>
                        <li>Manage stress through mindfulness and relaxation techniques</li>
                        <li>Get adequate sleep (7-8 hours per night)</li>
                      </ul>
                    </div>
                  </TabsContent>
                  <TabsContent value="monitoring">
                    <div>
                      <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-3">
                        Regular Health Monitoring
                      </h3>
                      <ul className="list-disc pl-5 text-slate-500 dark:text-slate-300 space-y-2">
                        <li>Annual physical examination with your healthcare provider</li>
                        <li>Regular blood glucose screening (fasting glucose test)</li>
                        <li>HbA1c testing every 1-2 years if at risk</li>
                        <li>Blood pressure monitoring</li>
                        <li>Cholesterol level checks</li>
                        <li>Regular eye examinations</li>
                        <li>Kidney function tests</li>
                        <li>Foot examinations if diabetic</li>
                      </ul>
                      <div className="mt-6">
                        <Button variant="outline">
                          Download Monitoring Schedule
                        </Button>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
