import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import { Card, CardContent } from "@/components/ui/card";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts";

export default function About() {
  // Training data metrics
  const accuracyData = [
    { name: "Training", value: 92 },
    { name: "Validation", value: 89 },
    { name: "Test", value: 87 },
  ];

  // Features importance (scaled 0-100)
  const featureImportanceData = [
    { name: "HbA1c", importance: 100 },
    { name: "Fasting Glucose", importance: 85 },
    { name: "BMI", importance: 62 },
    { name: "Age", importance: 45 },
    { name: "Hemoglobin", importance: 38 },
    { name: "Random Glucose", importance: 35 },
  ];

  // Model performance metrics
  const performanceData = [
    { name: "Accuracy", svm: 87, rf: 85, nn: 84 },
    { name: "Precision", svm: 89, rf: 83, nn: 86 },
    { name: "Recall", svm: 91, rf: 84, nn: 82 },
    { name: "F1 Score", svm: 90, rf: 83, nn: 84 },
  ];

  // Confusion matrix data
  const confusionMatrixData = [
    { name: "True Negative", value: 65 },
    { name: "False Positive", value: 8 },
    { name: "False Negative", value: 5 },
    { name: "True Positive", value: 22 },
  ];

  const COLORS = [
    "#0088FE",
    "#00C49F",
    "#FFBB28",
    "#FF8042",
    "#8884D8",
    "#82CA9D",
  ];

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />

      <main className="flex-1">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          {/* Hero section */}
          <div className="text-center mb-16">
            <h1 className="text-4xl font-extrabold text-slate-900 dark:text-white sm:text-5xl sm:tracking-tight lg:text-6xl font-sans">
              About Our ML Model
            </h1>
            <p className="mt-5 max-w-xl mx-auto text-xl text-slate-500 dark:text-slate-300">
              Our Support Vector Machine (SVM) model is trained to detect diabetes with high accuracy using multiple blood parameters
            </p>
          </div>

          {/* Model Architecture */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-6 font-sans">
              Model Architecture
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-medium text-slate-900 dark:text-white mb-4">
                    SVM Classification
                  </h3>
                  <p className="text-slate-500 dark:text-slate-300 mb-4">
                    We use a Support Vector Machine with an RBF kernel for classification, which effectively separates data points into different diabetes risk categories by finding optimal hyperplanes in a high-dimensional feature space.
                  </p>
                  <ul className="list-disc pl-5 text-slate-500 dark:text-slate-300 space-y-2">
                    <li>Kernel: Radial Basis Function (RBF)</li>
                    <li>Regularization Parameter (C): 1.0</li>
                    <li>Gamma: 'scale'</li>
                    <li>Probability Estimation: Enabled</li>
                  </ul>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-medium text-slate-900 dark:text-white mb-4">
                    Data Preprocessing
                  </h3>
                  <p className="text-slate-500 dark:text-slate-300 mb-4">
                    Our model incorporates several preprocessing steps to ensure optimal performance:
                  </p>
                  <ul className="list-disc pl-5 text-slate-500 dark:text-slate-300 space-y-2">
                    <li>Feature Scaling: StandardScaler for normalizing features</li>
                    <li>Train-Test Split: 70% training, 30% testing</li>
                    <li>Missing Value Handling: Intelligent imputation based on feature correlations</li>
                    <li>Outlier Detection and Treatment</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Model Performance */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-6 font-sans">
              Model Performance
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Accuracy Metrics */}
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-medium text-slate-900 dark:text-white mb-4">
                    Accuracy Metrics
                  </h3>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={accuracyData}
                        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis domain={[0, 100]} />
                        <Tooltip 
                          formatter={(value) => [`${value}%`, 'Accuracy']}
                          contentStyle={{ 
                            backgroundColor: "var(--card)", 
                            borderColor: "var(--border)",
                            color: "var(--card-foreground)" 
                          }}
                        />
                        <Legend />
                        <Bar 
                          dataKey="value" 
                          fill="hsl(var(--chart-1))" 
                          name="Accuracy (%)" 
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Feature Importance */}
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-medium text-slate-900 dark:text-white mb-4">
                    Feature Importance
                  </h3>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={featureImportanceData}
                        layout="vertical"
                        margin={{ top: 5, right: 30, left: 80, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" domain={[0, 100]} />
                        <YAxis 
                          type="category" 
                          dataKey="name" 
                          tick={{ fontSize: 12 }}
                        />
                        <Tooltip 
                          formatter={(value) => [`${value}%`, 'Relative Importance']}
                          contentStyle={{ 
                            backgroundColor: "var(--card)", 
                            borderColor: "var(--border)",
                            color: "var(--card-foreground)" 
                          }}
                        />
                        <Legend />
                        <Bar 
                          dataKey="importance" 
                          fill="hsl(var(--chart-2))" 
                          name="Importance (%)" 
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Comparative Model Performance */}
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-medium text-slate-900 dark:text-white mb-4">
                    Comparative Model Performance
                  </h3>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={performanceData}
                        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis domain={[75, 100]} />
                        <Tooltip 
                          formatter={(value) => [`${value}%`]}
                          contentStyle={{ 
                            backgroundColor: "var(--card)", 
                            borderColor: "var(--border)",
                            color: "var(--card-foreground)" 
                          }}
                        />
                        <Legend />
                        <Line
                          type="monotone"
                          dataKey="svm"
                          stroke="hsl(var(--chart-1))"
                          activeDot={{ r: 8 }}
                          name="SVM"
                        />
                        <Line
                          type="monotone"
                          dataKey="rf"
                          stroke="hsl(var(--chart-2))"
                          name="Random Forest"
                        />
                        <Line
                          type="monotone"
                          dataKey="nn"
                          stroke="hsl(var(--chart-3))"
                          name="Neural Network"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Confusion Matrix */}
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-medium text-slate-900 dark:text-white mb-4">
                    Confusion Matrix
                  </h3>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={confusionMatrixData}
                          cx="50%"
                          cy="50%"
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        >
                          {confusionMatrixData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip 
                          formatter={(value, name) => [`${value}%`, name]}
                          contentStyle={{ 
                            backgroundColor: "var(--card)", 
                            borderColor: "var(--border)",
                            color: "var(--card-foreground)" 
                          }}
                        />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Model Evaluation */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-6 font-sans">
              Model Evaluation
            </h2>
            <Card>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                  <div>
                    <h3 className="text-xl font-medium text-slate-900 dark:text-white">87%</h3>
                    <p className="text-slate-500 dark:text-slate-300">Overall Accuracy</p>
                  </div>
                  <div>
                    <h3 className="text-xl font-medium text-slate-900 dark:text-white">0.89</h3>
                    <p className="text-slate-500 dark:text-slate-300">AUC-ROC Score</p>
                  </div>
                  <div>
                    <h3 className="text-xl font-medium text-slate-900 dark:text-white">0.90</h3>
                    <p className="text-slate-500 dark:text-slate-300">F1 Score</p>
                  </div>
                </div>
                <div className="mt-8">
                  <h4 className="text-lg font-medium text-slate-900 dark:text-white mb-4">Key Findings</h4>
                  <ul className="list-disc pl-5 text-slate-500 dark:text-slate-300 space-y-2">
                    <li>The SVM model outperforms other machine learning algorithms for diabetes classification</li>
                    <li>HbA1c and fasting glucose are the strongest predictors of diabetes status</li>
                    <li>The model performs well across different age groups and demographics</li>
                    <li>Cross-validation shows consistent performance across different dataset splits</li>
                    <li>The RBF kernel provides better classification boundaries than linear or polynomial kernels</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
