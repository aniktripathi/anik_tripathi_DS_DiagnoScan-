import { useEffect } from "react";
import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";

import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import HealthCharts from "@/components/health-charts";
import AnalysisCards from "@/components/analysis-cards";
import Recommendations from "@/components/recommendations";
import { parseJsonIfString } from "@/lib/utils";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function Results() {
  const [match, params] = useRoute("/results/:id");
  const reportId = match ? parseInt(params.id, 10) : null;
  
  const { data: report, isLoading, error } = useQuery({
    queryKey: [reportId ? `/api/reports/${reportId}` : null],
    enabled: !!reportId,
  });
  
  // Scroll to top on initial load
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="py-12 bg-white dark:bg-slate-800 flex-grow">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="lg:text-center mb-12">
              <Skeleton className="h-8 w-64 mx-auto mb-4" />
              <Skeleton className="h-12 w-80 mx-auto" />
            </div>
            
            <div className="grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-3">
              <Skeleton className="h-64 w-full rounded-lg" />
              <Skeleton className="h-64 w-full rounded-lg" />
              <Skeleton className="h-64 w-full rounded-lg" />
            </div>
            
            <div className="mt-12">
              <Skeleton className="h-8 w-64 mx-auto mb-8" />
              <Skeleton className="h-72 w-full rounded-lg" />
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }
  
  if (error || !report) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="py-12 bg-white dark:bg-slate-800 flex-grow flex items-center justify-center">
          <Card className="w-full max-w-md mx-auto">
            <CardContent className="pt-6">
              <div className="text-center">
                <svg className="mx-auto h-12 w-12 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h2 className="mt-2 text-lg font-medium text-slate-900 dark:text-white">Failed to load report</h2>
                <p className="mt-1 text-sm text-slate-500 dark:text-slate-300">
                  {error instanceof Error ? error.message : "We couldn't find the report you're looking for. Please try again."}
                </p>
                <div className="mt-6">
                  <Button 
                    onClick={() => window.location.href = "/"} 
                    className="inline-flex items-center px-4 py-2"
                  >
                    Return to Dashboard
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }
  
  // Parse JSON strings into objects for recommendations
  const dietRecommendations = parseJsonIfString(report.recommendations?.[0]?.dietRecommendations || "{}");
  const exerciseRecommendations = parseJsonIfString(report.recommendations?.[0]?.exerciseRecommendations || "[]");
  const lifestyleRecommendations = parseJsonIfString(report.recommendations?.[0]?.lifestyleRecommendations || "[]");
  
  // Blood data for charts
  const bloodData = {
    haemoglobin: report.haemoglobin,
    fastingGlucose: report.fastingGlucose,
    randomGlucose: report.randomGlucose,
    hba1c: report.hba1c,
    age: report.age,
    bmi: report.bmi,
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="py-12 bg-white dark:bg-slate-800 flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:text-center mb-12">
            <h2 className="text-base text-primary-600 dark:text-primary-400 font-semibold tracking-wide uppercase font-sans">Analysis Results</h2>
            <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-4xl font-sans">
              Your Diabetes Assessment
            </p>
          </div>

          {/* Analysis Cards Section */}
          <AnalysisCards 
            diabetesStatus={report.diabetesStatus}
            isDiabetic={report.isDiabetic}
            bloodData={bloodData}
            confidenceScore={report.confidenceScore}
          />
          
          {/* Health Charts Section */}
          <HealthCharts bloodData={bloodData} />
          
          {/* Recommendations Section */}
          <Recommendations 
            dietRecommendations={dietRecommendations}
            exerciseRecommendations={exerciseRecommendations}
            lifestyleRecommendations={lifestyleRecommendations}
          />
          
          {/* Next Steps Section */}
          <div className="mt-12 text-center">
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-6 font-sans">
              Next Steps
            </h3>
            <div className="bg-white dark:bg-slate-700 shadow rounded-lg overflow-hidden">
              <div className="px-4 py-5 sm:p-6">
                <div className="max-w-xl mx-auto">
                  <p className="text-slate-500 dark:text-slate-300 mb-6">
                    Based on your results, we recommend the following next steps to manage your health effectively:
                  </p>
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <div className="flex-shrink-0 h-6 w-6 text-primary-500">
                        <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                      </div>
                      <div className="ml-3 text-left">
                        <p className="text-slate-700 dark:text-slate-200 font-medium">Schedule a follow-up with your healthcare provider</p>
                        <p className="text-sm text-slate-500 dark:text-slate-300">Share these results during your appointment</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="flex-shrink-0 h-6 w-6 text-primary-500">
                        <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                      </div>
                      <div className="ml-3 text-left">
                        <p className="text-slate-700 dark:text-slate-200 font-medium">Monitor your blood glucose regularly</p>
                        <p className="text-sm text-slate-500 dark:text-slate-300">Keep a log of your readings to track changes over time</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="flex-shrink-0 h-6 w-6 text-primary-500">
                        <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                      </div>
                      <div className="ml-3 text-left">
                        <p className="text-slate-700 dark:text-slate-200 font-medium">Re-test in 3 months</p>
                        <p className="text-sm text-slate-500 dark:text-slate-300">Upload your new results to track your progress</p>
                      </div>
                    </div>
                  </div>
                  <div className="mt-8">
                    <Button className="inline-flex items-center px-4 py-2">
                      <svg className="mr-2 h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                      </svg>
                      Download Report PDF
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
