import { useState } from "react";
import { Link } from "wouter";

import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import FeaturesSection from "@/components/features-section";
import ManualEntryForm from "@/components/manual-entry-form";
import UploadForm from "@/components/upload-form";
import { Button } from "@/components/ui/button";

export default function Home() {
  const [isManualEntryOpen, setIsManualEntryOpen] = useState(false);
  const [isUploadFormOpen, setIsUploadFormOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <div className="relative bg-white dark:bg-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
          <div className="lg:grid lg:grid-cols-12 lg:gap-8">
            <div className="sm:text-center md:max-w-2xl md:mx-auto lg:col-span-6 lg:text-left">
              <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-5xl md:text-6xl lg:text-5xl xl:text-6xl font-sans">
                <span className="block">Advanced Diabetes</span>
                <span className="block text-primary-600 dark:text-primary-400">Detection & Analysis</span>
              </h1>
              <p className="mt-3 text-base text-slate-500 dark:text-slate-300 sm:mt-5 sm:text-xl lg:text-lg xl:text-xl">
                Upload your blood report and get instant insights about your diabetes risk. Our AI-powered analysis uses advanced machine learning to provide personalized health recommendations.
              </p>
              <div className="mt-8 sm:max-w-lg sm:mx-auto sm:text-center lg:text-left lg:mx-0">
                <p className="text-base font-medium text-slate-700 dark:text-slate-200">
                  Start your analysis in minutes
                </p>
                
                <div className="mt-3 sm:flex">
                  <Button
                    onClick={() => setIsUploadFormOpen(true)}
                    className="w-full flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 dark:focus:ring-offset-slate-800 shadow-sm"
                  >
                    <svg className="mr-2 h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                    Upload Blood Report
                  </Button>
                  <Button
                    onClick={() => setIsManualEntryOpen(true)}
                    variant="outline"
                    className="mt-3 sm:mt-0 sm:ml-3 w-full flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-primary-700 bg-primary-100 hover:bg-primary-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 dark:text-primary-200 dark:bg-slate-700 dark:hover:bg-slate-600 dark:focus:ring-offset-slate-800 shadow-sm"
                  >
                    <svg className="mr-2 h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                    Manual Entry
                  </Button>
                </div>
              </div>
            </div>
            <div className="mt-12 relative sm:max-w-lg sm:mx-auto lg:mt-0 lg:max-w-none lg:mx-0 lg:col-span-6 lg:flex lg:items-center">
              <div className="relative mx-auto w-full rounded-lg shadow-lg lg:max-w-md">
                <div className="relative block w-full bg-white dark:bg-slate-700 rounded-lg overflow-hidden">
                  <div className="w-full h-64 bg-slate-100 dark:bg-slate-600 rounded-lg">
                    <div className="flex items-center justify-center h-full">
                      <svg 
                        className="animate-pulse w-12 h-12 text-primary-500"
                        fill="none" 
                        viewBox="0 0 24 24" 
                        stroke="currentColor"
                      >
                        <path 
                          strokeLinecap="round" 
                          strokeLinejoin="round" 
                          strokeWidth={2} 
                          d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" 
                        />
                      </svg>
                    </div>
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center p-4 bg-white dark:bg-slate-800 bg-opacity-90 dark:bg-opacity-90 rounded-lg shadow-md">
                      <p className="text-sm font-medium text-slate-500 dark:text-slate-300">
                        Interactive Health Visualization
                      </p>
                      <p className="text-base font-semibold text-slate-900 dark:text-white">
                        See how your health metrics compare
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Features Section */}
      <FeaturesSection />
      
      {/* Manual Entry Form Modal */}
      <ManualEntryForm 
        isOpen={isManualEntryOpen} 
        onClose={() => setIsManualEntryOpen(false)} 
      />
      
      {/* Upload Form Modal */}
      <UploadForm 
        isOpen={isUploadFormOpen} 
        onClose={() => setIsUploadFormOpen(false)} 
      />
      
      <Footer />
    </div>
  );
}
