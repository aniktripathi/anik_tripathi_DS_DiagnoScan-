import {
  Card,
  CardContent,
} from "@/components/ui/card";

interface DietRecommendations {
  include: string[];
  avoid: string[];
}

interface ExerciseRecommendation {
  name: string;
  duration: string;
  frequency: string;
  icon?: string;
}

interface LifestyleRecommendation {
  name: string;
  description: string;
  icon?: string;
}

interface RecommendationsProps {
  dietRecommendations: DietRecommendations;
  exerciseRecommendations: ExerciseRecommendation[];
  lifestyleRecommendations: LifestyleRecommendation[];
}

export default function Recommendations({
  dietRecommendations,
  exerciseRecommendations,
  lifestyleRecommendations
}: RecommendationsProps) {
  
  // Icon mapping function for exercise recommendations
  const getExerciseIcon = (icon?: string) => {
    switch (icon) {
      case 'walking':
        return <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
        </svg>;
      case 'bicycle':
        return <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
        </svg>;
      case 'dumbbell':
        return <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5v-4m0 4h-4m4 0l-5-5" />
        </svg>;
      case 'swimming-pool':
        return <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>;
      default:
        return <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
        </svg>;
    }
  };
  
  // Icon mapping function for lifestyle recommendations
  const getLifestyleIcon = (icon?: string) => {
    switch (icon) {
      case 'clock':
        return <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>;
      case 'moon':
        return <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
        </svg>;
      case 'tint':
        return <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
        </svg>;
      case 'ban':
        return <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
        </svg>;
      case 'peace':
        return <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
        </svg>;
      case 'microscope':
        return <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
        </svg>;
      default:
        return <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
        </svg>;
    }
  };
  
  return (
    <div className="mt-12">
      <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-6 font-sans text-center">
        Personalized Health Recommendations
      </h3>
      
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {/* Diet Recommendations */}
        <Card className="overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center mb-4">
              <div className="flex-shrink-0 bg-green-100 dark:bg-green-900 rounded-md p-3">
                <svg className="h-6 w-6 text-green-600 dark:text-green-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" />
                </svg>
              </div>
              <h4 className="ml-3 text-lg font-medium text-slate-900 dark:text-white">Diet Recommendations</h4>
            </div>
            <div className="space-y-4">
              <div>
                <h5 className="text-sm font-medium text-slate-900 dark:text-white">Foods to Include</h5>
                <ul className="mt-2 text-sm text-slate-500 dark:text-slate-300 space-y-1">
                  {dietRecommendations?.include?.map((food, index) => (
                    <li key={index} className="flex items-start">
                      <svg className="text-green-500 mt-0.5 mr-2 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      <span>{food}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h5 className="text-sm font-medium text-slate-900 dark:text-white">Foods to Avoid</h5>
                <ul className="mt-2 text-sm text-slate-500 dark:text-slate-300 space-y-1">
                  {dietRecommendations?.avoid?.map((food, index) => (
                    <li key={index} className="flex items-start">
                      <svg className="text-red-500 mt-0.5 mr-2 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                      <span>{food}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Exercise Recommendations */}
        <Card className="overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center mb-4">
              <div className="flex-shrink-0 bg-blue-100 dark:bg-blue-900 rounded-md p-3">
                <svg className="h-6 w-6 text-blue-600 dark:text-blue-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h4 className="ml-3 text-lg font-medium text-slate-900 dark:text-white">Exercise Recommendations</h4>
            </div>
            <div className="space-y-4">
              <div>
                <h5 className="text-sm font-medium text-slate-900 dark:text-white">Recommended Activities</h5>
                <ul className="mt-2 text-sm text-slate-500 dark:text-slate-300 space-y-2">
                  {exerciseRecommendations?.map((exercise, index) => (
                    <li key={index} className="flex items-start">
                      <div className="flex-shrink-0 h-5 w-5 text-blue-500">
                        {getExerciseIcon(exercise.icon)}
                      </div>
                      <div className="ml-3">
                        <span className="font-medium text-slate-700 dark:text-slate-200">{exercise.name}</span>
                        <p>{exercise.duration}, {exercise.frequency}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Lifestyle Modifications */}
        <Card className="overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-center mb-4">
              <div className="flex-shrink-0 bg-purple-100 dark:bg-purple-900 rounded-md p-3">
                <svg className="h-6 w-6 text-purple-600 dark:text-purple-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                </svg>
              </div>
              <h4 className="ml-3 text-lg font-medium text-slate-900 dark:text-white">Lifestyle Modifications</h4>
            </div>
            <div className="space-y-4">
              <div>
                <h5 className="text-sm font-medium text-slate-900 dark:text-white">Daily Habits</h5>
                <ul className="mt-2 text-sm text-slate-500 dark:text-slate-300 space-y-2">
                  {lifestyleRecommendations?.map((lifestyle, index) => (
                    <li key={index} className="flex items-start">
                      <div className="flex-shrink-0 h-5 w-5 text-purple-500">
                        {getLifestyleIcon(lifestyle.icon)}
                      </div>
                      <div className="ml-3">
                        <span className="font-medium text-slate-700 dark:text-slate-200">{lifestyle.name}</span>
                        <p>{lifestyle.description}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
