import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { BloodReportInsert, bloodReportInsertSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface ManualEntryFormProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ManualEntryForm({ isOpen, onClose }: ManualEntryFormProps) {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  
  const form = useForm<BloodReportInsert>({
    resolver: zodResolver(bloodReportInsertSchema),
    defaultValues: {
      haemoglobin: undefined,
      fastingGlucose: undefined,
      randomGlucose: undefined,
      hba1c: undefined,
      rbc: undefined,
      wbc: undefined,
      platelets: undefined,
      cholesterol: undefined,
      triglycerides: undefined,
      hdl: undefined,
      ldl: undefined,
      creatinine: undefined,
      urea: undefined,
      sodium: undefined,
      potassium: undefined,
      chloride: undefined,
      age: undefined,
      bmi: undefined,
    },
  });
  
  const analyzeMutation = useMutation({
    mutationFn: async (data: BloodReportInsert) => {
      const response = await apiRequest("POST", "/api/analyze", data);
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Analysis Complete",
        description: "Your blood report has been analyzed successfully.",
      });
      onClose();
      navigate(`/results/${data.reportId}`);
    },
    onError: (error) => {
      toast({
        title: "Analysis Failed",
        description: error instanceof Error ? error.message : "Failed to analyze blood report. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: BloodReportInsert) => {
    analyzeMutation.mutate(data);
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-3xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-lg font-medium text-slate-900 dark:text-white font-sans">
            Enter Blood Report Values
          </DialogTitle>
          <DialogDescription>
            Enter your blood test values below for diabetes risk analysis.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
              <FormField
                control={form.control}
                name="haemoglobin"
                render={({ field }) => (
                  <FormItem className="sm:col-span-3">
                    <FormLabel className="block text-sm font-medium text-slate-700 dark:text-slate-200">
                      Haemoglobin (g/dL)
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.1"
                        placeholder="12.0-16.0"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-md"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value === "" ? undefined : parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="fastingGlucose"
                render={({ field }) => (
                  <FormItem className="sm:col-span-3">
                    <FormLabel className="block text-sm font-medium text-slate-700 dark:text-slate-200">
                      Fasting Plasma Glucose (mg/dL)
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        placeholder="70-100"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-md"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value === "" ? undefined : parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="randomGlucose"
                render={({ field }) => (
                  <FormItem className="sm:col-span-3">
                    <FormLabel className="block text-sm font-medium text-slate-700 dark:text-slate-200">
                      Random Plasma Glucose (mg/dL)
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        placeholder="70-140"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-md"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value === "" ? undefined : parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="hba1c"
                render={({ field }) => (
                  <FormItem className="sm:col-span-3">
                    <FormLabel className="block text-sm font-medium text-slate-700 dark:text-slate-200">
                      HbA1c (%)
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.1"
                        placeholder="4.0-5.6"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-md"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value === "" ? undefined : parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="age"
                render={({ field }) => (
                  <FormItem className="sm:col-span-3">
                    <FormLabel className="block text-sm font-medium text-slate-700 dark:text-slate-200">
                      Age
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        placeholder="18-120"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-md"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value === "" ? undefined : parseInt(e.target.value, 10))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="bmi"
                render={({ field }) => (
                  <FormItem className="sm:col-span-3">
                    <FormLabel className="block text-sm font-medium text-slate-700 dark:text-slate-200">
                      BMI
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.1"
                        placeholder="18.5-24.9"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-md"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value === "" ? undefined : parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Complete Blood Count Parameters */}
              <div className="sm:col-span-6 mt-6 mb-3">
                <h3 className="text-lg font-medium text-slate-900 dark:text-white">Complete Blood Count</h3>
              </div>
              
              <FormField
                control={form.control}
                name="rbc"
                render={({ field }) => (
                  <FormItem className="sm:col-span-3">
                    <FormLabel className="block text-sm font-medium text-slate-700 dark:text-slate-200">
                      RBC (million/μL)
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.1"
                        placeholder="4.5-5.9"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-md"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value === "" ? undefined : parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="wbc"
                render={({ field }) => (
                  <FormItem className="sm:col-span-3">
                    <FormLabel className="block text-sm font-medium text-slate-700 dark:text-slate-200">
                      WBC (thousand/μL)
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.1"
                        placeholder="4.5-11.0"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-md"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value === "" ? undefined : parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="platelets"
                render={({ field }) => (
                  <FormItem className="sm:col-span-3">
                    <FormLabel className="block text-sm font-medium text-slate-700 dark:text-slate-200">
                      Platelets (thousand/μL)
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="1"
                        placeholder="150-450"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-md"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value === "" ? undefined : parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Lipid Profile Parameters */}
              <div className="sm:col-span-6 mt-6 mb-3">
                <h3 className="text-lg font-medium text-slate-900 dark:text-white">Lipid Profile</h3>
              </div>
              
              <FormField
                control={form.control}
                name="cholesterol"
                render={({ field }) => (
                  <FormItem className="sm:col-span-3">
                    <FormLabel className="block text-sm font-medium text-slate-700 dark:text-slate-200">
                      Total Cholesterol (mg/dL)
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="1"
                        placeholder="125-200"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-md"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value === "" ? undefined : parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="triglycerides"
                render={({ field }) => (
                  <FormItem className="sm:col-span-3">
                    <FormLabel className="block text-sm font-medium text-slate-700 dark:text-slate-200">
                      Triglycerides (mg/dL)
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="1"
                        placeholder="40-150"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-md"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value === "" ? undefined : parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="hdl"
                render={({ field }) => (
                  <FormItem className="sm:col-span-3">
                    <FormLabel className="block text-sm font-medium text-slate-700 dark:text-slate-200">
                      HDL (mg/dL)
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="1"
                        placeholder="40-60"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-md"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value === "" ? undefined : parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="ldl"
                render={({ field }) => (
                  <FormItem className="sm:col-span-3">
                    <FormLabel className="block text-sm font-medium text-slate-700 dark:text-slate-200">
                      LDL (mg/dL)
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="1"
                        placeholder="70-130"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-md"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value === "" ? undefined : parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Kidney Function Parameters */}
              <div className="sm:col-span-6 mt-6 mb-3">
                <h3 className="text-lg font-medium text-slate-900 dark:text-white">Kidney Function Tests</h3>
              </div>
              
              <FormField
                control={form.control}
                name="creatinine"
                render={({ field }) => (
                  <FormItem className="sm:col-span-3">
                    <FormLabel className="block text-sm font-medium text-slate-700 dark:text-slate-200">
                      Creatinine (mg/dL)
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.1"
                        placeholder="0.6-1.2"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-md"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value === "" ? undefined : parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="urea"
                render={({ field }) => (
                  <FormItem className="sm:col-span-3">
                    <FormLabel className="block text-sm font-medium text-slate-700 dark:text-slate-200">
                      Urea (mg/dL)
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="1"
                        placeholder="5-20"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-md"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value === "" ? undefined : parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Electrolytes */}
              <div className="sm:col-span-6 mt-6 mb-3">
                <h3 className="text-lg font-medium text-slate-900 dark:text-white">Electrolytes</h3>
              </div>
              
              <FormField
                control={form.control}
                name="sodium"
                render={({ field }) => (
                  <FormItem className="sm:col-span-2">
                    <FormLabel className="block text-sm font-medium text-slate-700 dark:text-slate-200">
                      Sodium (mEq/L)
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="1"
                        placeholder="135-145"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-md"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value === "" ? undefined : parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="potassium"
                render={({ field }) => (
                  <FormItem className="sm:col-span-2">
                    <FormLabel className="block text-sm font-medium text-slate-700 dark:text-slate-200">
                      Potassium (mEq/L)
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.1"
                        placeholder="3.5-5.0"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-md"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value === "" ? undefined : parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="chloride"
                render={({ field }) => (
                  <FormItem className="sm:col-span-2">
                    <FormLabel className="block text-sm font-medium text-slate-700 dark:text-slate-200">
                      Chloride (mEq/L)
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="1"
                        placeholder="96-106"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-white rounded-md"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value === "" ? undefined : parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <DialogFooter className="mt-5 sm:mt-6 sm:grid sm:grid-cols-2 sm:gap-3 sm:grid-flow-row-dense">
              <Button
                type="submit"
                disabled={analyzeMutation.isPending}
                className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-primary-600 text-base font-medium text-white hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 dark:focus:ring-offset-slate-800 sm:col-start-2 sm:text-sm"
              >
                {analyzeMutation.isPending ? "Analyzing..." : "Analyze Report"}
              </Button>
              
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={analyzeMutation.isPending}
                className="mt-3 w-full inline-flex justify-center rounded-md border border-slate-300 dark:border-slate-600 shadow-sm px-4 py-2 bg-white dark:bg-slate-700 text-base font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 dark:focus:ring-offset-slate-800 sm:mt-0 sm:col-start-1 sm:text-sm"
              >
                Cancel
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
