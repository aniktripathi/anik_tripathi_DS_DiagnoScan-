import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts";
import { 
  normalRanges, 
  preDiabeticRanges, 
  diabeticRanges,
  formatNumber
} from "@/lib/utils";

interface HealthChartsProps {
  bloodData: {
    haemoglobin: number;
    fastingGlucose: number;
    randomGlucose?: number;
    hba1c: number;
    age: number;
    bmi: number;
  };
}

export function GlucoseChart({ bloodData }: HealthChartsProps) {
  const data = [
    {
      name: "Fasting Glucose",
      "Your Value": bloodData.fastingGlucose,
      "Normal Range": (normalRanges.fastingGlucose.min + normalRanges.fastingGlucose.max) / 2,
      "Pre-diabetic Range": (preDiabeticRanges.fastingGlucose.min + preDiabeticRanges.fastingGlucose.max) / 2,
      "Diabetic Range": diabeticRanges.fastingGlucose.min,
    },
    {
      name: "Random Glucose",
      "Your Value": bloodData.randomGlucose || 0,
      "Normal Range": (normalRanges.randomGlucose.min + normalRanges.randomGlucose.max) / 2,
      "Pre-diabetic Range": (preDiabeticRanges.randomGlucose.min + preDiabeticRanges.randomGlucose.max) / 2,
      "Diabetic Range": diabeticRanges.randomGlucose.min,
    },
  ];

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={data}
        margin={{
          top: 5,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip 
          formatter={(value) => `${formatNumber(value as number, 1)} mg/dL`}
          labelStyle={{ color: "var(--foreground)" }}
          contentStyle={{ 
            backgroundColor: "var(--card)", 
            borderColor: "var(--border)",
            color: "var(--card-foreground)" 
          }}
        />
        <Legend />
        <Bar dataKey="Your Value" fill="hsl(var(--chart-1))" />
        <Bar dataKey="Normal Range" fill="hsl(var(--chart-2))" />
        <Bar dataKey="Pre-diabetic Range" fill="hsl(var(--chart-3))" />
        <Bar dataKey="Diabetic Range" fill="hsl(var(--chart-4))" />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function HaemoglobinChart({ bloodData }: HealthChartsProps) {
  const getRiskScore = (age: number) => {
    if (age < 40) return 20;
    if (age < 50) return 40;
    if (age < 60) return 60;
    if (age < 70) return 80;
    return 100;
  };

  const data = [
    {
      subject: "Haemoglobin",
      "Your Values": bloodData.haemoglobin,
      "Normal Range": normalRanges.haemoglobin.max,
      fullMark: 20,
    },
    {
      subject: "HbA1c",
      "Your Values": bloodData.hba1c * 2, // Scale for better visualization
      "Normal Range": normalRanges.hba1c.max * 2,
      fullMark: 15,
    },
    {
      subject: "BMI",
      "Your Values": bloodData.bmi,
      "Normal Range": (normalRanges.bmi.min + normalRanges.bmi.max) / 2,
      fullMark: 40,
    },
    {
      subject: "Age Risk",
      "Your Values": getRiskScore(bloodData.age),
      "Normal Range": 40, // arbitrary reference point
      fullMark: 100,
    },
  ];

  return (
    <ResponsiveContainer width="100%" height="100%">
      <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
        <PolarGrid />
        <PolarAngleAxis dataKey="subject" />
        <PolarRadiusAxis />
        <Radar
          name="Your Values"
          dataKey="Your Values"
          stroke="hsl(var(--chart-1))"
          fill="hsl(var(--chart-1))"
          fillOpacity={0.2}
        />
        <Radar
          name="Normal Range"
          dataKey="Normal Range"
          stroke="hsl(var(--chart-2))"
          fill="hsl(var(--chart-2))"
          fillOpacity={0.2}
        />
        <Legend />
        <Tooltip 
          formatter={(value) => formatNumber(value as number, 1)}
          labelStyle={{ color: "var(--foreground)" }}
          contentStyle={{ 
            backgroundColor: "var(--card)", 
            borderColor: "var(--border)",
            color: "var(--card-foreground)" 
          }}
        />
      </RadarChart>
    </ResponsiveContainer>
  );
}

export function TrendChart() {
  // Sample trend data - in a real app, this would come from historical data
  const data = [
    { month: "Jan", glucose: 110, hba1c: 5.8 },
    { month: "Feb", glucose: 115, hba1c: 5.9 },
    { month: "Mar", glucose: 125, hba1c: 6.0 },
    { month: "Apr", glucose: 130, hba1c: 6.1 },
    { month: "May", glucose: 125, hba1c: 6.0 },
    { month: "Jun", glucose: 115, hba1c: 5.9 },
  ];

  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart
        data={data}
        margin={{
          top: 5,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="month" />
        <YAxis yAxisId="left" />
        <YAxis yAxisId="right" orientation="right" />
        <Tooltip 
          labelStyle={{ color: "var(--foreground)" }}
          contentStyle={{ 
            backgroundColor: "var(--card)", 
            borderColor: "var(--border)",
            color: "var(--card-foreground)" 
          }}
        />
        <Legend />
        <Line
          yAxisId="left"
          type="monotone"
          dataKey="glucose"
          stroke="hsl(var(--chart-1))"
          activeDot={{ r: 8 }}
          name="Fasting Glucose (mg/dL)"
        />
        <Line
          yAxisId="right"
          type="monotone"
          dataKey="hba1c"
          stroke="hsl(var(--chart-2))"
          name="HbA1c (%)"
        />
      </LineChart>
    </ResponsiveContainer>
  );
}

export default function HealthCharts({ bloodData }: HealthChartsProps) {
  return (
    <div className="mt-12">
      <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-6 font-sans text-center">
        Your Health Data Visualization
      </h3>
      
      <div className="bg-white dark:bg-slate-700 shadow rounded-lg overflow-hidden">
        <div className="px-4 py-5 sm:p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div>
              <h4 className="text-lg font-medium text-slate-900 dark:text-white mb-4">Blood Glucose Levels</h4>
              <div className="h-64 relative">
                <GlucoseChart bloodData={bloodData} />
              </div>
              <div className="mt-2 text-sm text-slate-500 dark:text-slate-300 text-center">
                Your levels compared to normal ranges
              </div>
            </div>
            <div>
              <h4 className="text-lg font-medium text-slate-900 dark:text-white mb-4">HbA1c & Haemoglobin</h4>
              <div className="h-64 relative">
                <HaemoglobinChart bloodData={bloodData} />
              </div>
              <div className="mt-2 text-sm text-slate-500 dark:text-slate-300 text-center">
                Your levels compared to normal ranges
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
