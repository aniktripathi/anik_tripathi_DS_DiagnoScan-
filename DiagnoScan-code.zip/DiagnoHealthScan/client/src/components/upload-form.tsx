import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

interface UploadFormProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function UploadForm({ isOpen, onClose }: UploadFormProps) {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const [reportFile, setReportFile] = useState<File | null>(null);
  const [datasetFile, setDatasetFile] = useState<File | null>(null);
  const reportFileInputRef = useRef<HTMLInputElement>(null);
  const datasetFileInputRef = useRef<HTMLInputElement>(null);
  
  const uploadReportMutation = useMutation({
    mutationFn: async () => {
      if (!reportFile) throw new Error("No file selected");
      
      const formData = new FormData();
      formData.append("file", reportFile);
      
      const response = await fetch("/api/analyze/pdf", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to upload report");
      }
      
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Upload Complete",
        description: "Your blood report has been analyzed successfully.",
      });
      
      // Also upload dataset if provided
      if (datasetFile) {
        uploadDatasetMutation.mutate();
      }
      
      onClose();
      navigate(`/results/${data.reportId}`);
    },
    onError: (error) => {
      toast({
        title: "Upload Failed",
        description: error instanceof Error ? error.message : "Failed to upload and analyze blood report. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  const uploadDatasetMutation = useMutation({
    mutationFn: async () => {
      if (!datasetFile) throw new Error("No dataset file selected");
      
      const formData = new FormData();
      formData.append("file", datasetFile);
      formData.append("name", datasetFile.name);
      formData.append("description", "Custom dataset uploaded with blood report");
      
      const response = await apiRequest("POST", "/api/datasets", formData);
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Dataset Uploaded",
        description: "Your custom dataset has been uploaded successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Dataset Upload Failed",
        description: error instanceof Error ? error.message : "Failed to upload custom dataset. Your report analysis will continue with our default dataset.",
        variant: "destructive",
      });
    },
  });
  
  const handleReportDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      setReportFile(e.dataTransfer.files[0]);
    }
  };
  
  const handleDatasetDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      setDatasetFile(e.dataTransfer.files[0]);
    }
  };
  
  const handleReportClick = () => {
    if (reportFileInputRef.current) {
      reportFileInputRef.current.click();
    }
  };
  
  const handleDatasetClick = () => {
    if (datasetFileInputRef.current) {
      datasetFileInputRef.current.click();
    }
  };
  
  const handleSubmit = () => {
    if (reportFile) {
      uploadReportMutation.mutate();
    } else {
      toast({
        title: "No File Selected",
        description: "Please select a blood report PDF file to upload.",
        variant: "destructive",
      });
    }
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-lg font-medium text-slate-900 dark:text-white font-sans">
            Upload Blood Report PDF
          </DialogTitle>
          <DialogDescription>
            Upload your blood report in PDF format for analysis. We'll extract the values automatically.
          </DialogDescription>
        </DialogHeader>
        
        <div className="mt-4">
          <div 
            className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-slate-300 dark:border-slate-600 border-dashed rounded-md"
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleReportDrop}
            onClick={handleReportClick}
          >
            <div className="space-y-1 text-center">
              {reportFile ? (
                <div className="flex flex-col items-center">
                  <svg className="mx-auto h-12 w-12 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span className="text-sm text-slate-600 dark:text-slate-300">{reportFile.name}</span>
                </div>
              ) : (
                <>
                  <svg className="mx-auto h-12 w-12 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  <div className="flex text-sm text-slate-600 dark:text-slate-300">
                    <Label htmlFor="file-upload" className="relative cursor-pointer bg-white dark:bg-slate-700 rounded-md font-medium text-primary-600 dark:text-primary-400 hover:text-primary-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-primary-500 dark:focus-within:ring-offset-slate-800">
                      <span>Upload a file</span>
                      <input 
                        id="file-upload" 
                        name="file-upload" 
                        type="file" 
                        className="sr-only" 
                        accept=".pdf"
                        ref={reportFileInputRef}
                        onChange={(e) => {
                          if (e.target.files && e.target.files.length > 0) {
                            setReportFile(e.target.files[0]);
                          }
                        }}
                      />
                    </Label>
                    <p className="pl-1">or drag and drop</p>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    PDF file of your blood report
                  </p>
                </>
              )}
            </div>
          </div>
          
          <div className="mt-4">
            <div className="relative">
              <div className="flex items-center justify-between">
                <Label className="block text-sm font-medium text-slate-700 dark:text-slate-200 text-left">
                  Or upload your own dataset for custom training (optional)
                </Label>
              </div>
              <div 
                className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-slate-300 dark:border-slate-600 border-dashed rounded-md"
                onDragOver={(e) => e.preventDefault()}
                onDrop={handleDatasetDrop}
                onClick={handleDatasetClick}
              >
                <div className="space-y-1 text-center">
                  {datasetFile ? (
                    <div className="flex flex-col items-center">
                      <svg className="mx-auto h-12 w-12 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <span className="text-sm text-slate-600 dark:text-slate-300">{datasetFile.name}</span>
                    </div>
                  ) : (
                    <>
                      <svg className="mx-auto h-12 w-12 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                      </svg>
                      <div className="flex text-sm text-slate-600 dark:text-slate-300">
                        <Label htmlFor="dataset-upload" className="relative cursor-pointer bg-white dark:bg-slate-700 rounded-md font-medium text-primary-600 dark:text-primary-400 hover:text-primary-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-primary-500 dark:focus-within:ring-offset-slate-800">
                          <span>Upload dataset</span>
                          <input 
                            id="dataset-upload" 
                            name="dataset-upload" 
                            type="file" 
                            className="sr-only" 
                            accept=".csv"
                            ref={datasetFileInputRef}
                            onChange={(e) => {
                              if (e.target.files && e.target.files.length > 0) {
                                setDatasetFile(e.target.files[0]);
                              }
                            }}
                          />
                        </Label>
                        <p className="pl-1">for custom model training</p>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        CSV with labeled data (70:30 split will be applied)
                      </p>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <DialogFooter className="mt-5 sm:mt-6 sm:grid sm:grid-cols-2 sm:gap-3 sm:grid-flow-row-dense">
          <Button
            type="button"
            onClick={handleSubmit}
            disabled={uploadReportMutation.isPending}
            className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-primary-600 text-base font-medium text-white hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 dark:focus:ring-offset-slate-800 sm:col-start-2 sm:text-sm"
          >
            {uploadReportMutation.isPending ? "Processing..." : "Process Upload"}
          </Button>
          
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
            disabled={uploadReportMutation.isPending}
            className="mt-3 w-full inline-flex justify-center rounded-md border border-slate-300 dark:border-slate-600 shadow-sm px-4 py-2 bg-white dark:bg-slate-700 text-base font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 dark:focus:ring-offset-slate-800 sm:mt-0 sm:col-start-1 sm:text-sm"
          >
            Cancel
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
