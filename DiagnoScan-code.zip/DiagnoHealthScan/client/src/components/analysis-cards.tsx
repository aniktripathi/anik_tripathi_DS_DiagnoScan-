import { formatNumber, getStatusClass, getStatusText } from "@/lib/utils";

import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface BloodData {
  haemoglobin: number;
  fastingGlucose: number;
  randomGlucose?: number;
  hba1c: number;
  age: number;
  bmi: number;
}

interface AnalysisCardsProps {
  diabetesStatus: string;
  isDiabetic: boolean;
  bloodData: BloodData;
  confidenceScore: number;
}

export default function AnalysisCards({
  diabetesStatus,
  isDiabetic,
  bloodData,
  confidenceScore
}: AnalysisCardsProps) {
  
  // Determine status color for the risk bar
  let statusColor = "bg-green-500";
  let riskPercentage = 25;
  
  if (diabetesStatus === "Pre-diabetic") {
    statusColor = "bg-yellow-500";
    riskPercentage = 65;
  } else if (diabetesStatus === "Diabetic") {
    statusColor = "bg-red-500";
    riskPercentage = 95;
  }
  
  return (
    <div className="grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-3">
      {/* Diabetes Status Card */}
      <Card className="overflow-hidden">
        <CardContent className="p-6">
          <div className="flex items-center">
            <div className={`flex-shrink-0 ${diabetesStatus === "Normal" ? "bg-green-100 dark:bg-green-900" : diabetesStatus === "Pre-diabetic" ? "bg-yellow-100 dark:bg-yellow-900" : "bg-red-100 dark:bg-red-900"} rounded-md p-3`}>
              <svg 
                className={`${diabetesStatus === "Normal" ? "text-green-600 dark:text-green-300" : diabetesStatus === "Pre-diabetic" ? "text-yellow-600 dark:text-yellow-300" : "text-red-600 dark:text-red-300"} h-6 w-6`}
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-slate-500 dark:text-slate-300 truncate">
                  Diabetes Status
                </dt>
                <dd>
                  <div className={`text-lg font-medium ${diabetesStatus === "Normal" ? "text-green-600 dark:text-green-300" : diabetesStatus === "Pre-diabetic" ? "text-yellow-600 dark:text-yellow-300" : "text-red-600 dark:text-red-300"}`}>
                    {diabetesStatus}
                  </div>
                </dd>
              </dl>
            </div>
          </div>
          <div className="mt-6">
            <div className="relative pt-1">
              <div className="text-xs mb-1 text-slate-500 dark:text-slate-300">Risk Level</div>
              <Progress value={riskPercentage} className="bg-slate-200 dark:bg-slate-600 h-2" indicatorClassName={statusColor} />
              <div className="flex justify-between mt-1 text-xs text-slate-500 dark:text-slate-400">
                <span>Normal</span>
                <span>Pre-diabetic</span>
                <span>Diabetic</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Metrics Card */}
      <Card className="overflow-hidden">
        <CardContent className="p-6">
          <h3 className="text-lg leading-6 font-medium text-slate-900 dark:text-white mb-5">Key Metrics</h3>
          <div className="grid grid-cols-1 gap-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="flex-shrink-0 h-10 w-10 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center">
                  <svg className="h-6 w-6 text-primary-600 dark:text-primary-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                  </svg>
                </div>
                <div className="ml-4">
                  <div className="text-sm font-medium text-slate-900 dark:text-white">Haemoglobin</div>
                  <div className="text-sm text-slate-500 dark:text-slate-300">{formatNumber(bloodData.haemoglobin)} g/dL</div>
                </div>
              </div>
              <div className={`text-sm ${getStatusClass(bloodData.haemoglobin, 'haemoglobin')}`}>
                {getStatusText(bloodData.haemoglobin, 'haemoglobin')}
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="flex-shrink-0 h-10 w-10 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center">
                  <svg className="h-6 w-6 text-primary-600 dark:text-primary-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                  </svg>
                </div>
                <div className="ml-4">
                  <div className="text-sm font-medium text-slate-900 dark:text-white">Fasting Glucose</div>
                  <div className="text-sm text-slate-500 dark:text-slate-300">{formatNumber(bloodData.fastingGlucose)} mg/dL</div>
                </div>
              </div>
              <div className={`text-sm ${getStatusClass(bloodData.fastingGlucose, 'fastingGlucose')}`}>
                {getStatusText(bloodData.fastingGlucose, 'fastingGlucose')}
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="flex-shrink-0 h-10 w-10 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center">
                  <svg className="h-6 w-6 text-primary-600 dark:text-primary-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                  </svg>
                </div>
                <div className="ml-4">
                  <div className="text-sm font-medium text-slate-900 dark:text-white">HbA1c</div>
                  <div className="text-sm text-slate-500 dark:text-slate-300">{formatNumber(bloodData.hba1c)}%</div>
                </div>
              </div>
              <div className={`text-sm ${getStatusClass(bloodData.hba1c, 'hba1c')}`}>
                {getStatusText(bloodData.hba1c, 'hba1c')}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Model Confidence Card */}
      <Card className="overflow-hidden">
        <CardContent className="p-6">
          <h3 className="text-lg leading-6 font-medium text-slate-900 dark:text-white">ML Model Confidence</h3>
          <div className="mt-2">
            <p className="text-sm text-slate-500 dark:text-slate-300">
              Our SVM model analysis is based on a comprehensive training dataset with a 70:30 train-test split.
            </p>
          </div>
          <div className="mt-5">
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium text-slate-500 dark:text-slate-300">Prediction Confidence</div>
              <div className="text-sm font-medium text-slate-900 dark:text-white">{formatNumber(confidenceScore)}%</div>
            </div>
            <div className="mt-2">
              <div className="bg-slate-200 dark:bg-slate-600 rounded-full overflow-hidden">
                <div 
                  className="h-2 bg-primary-600 rounded-full" 
                  style={{ width: `${confidenceScore}%` }}
                ></div>
              </div>
            </div>
          </div>
          <div className="mt-6">
            <h4 className="text-sm font-medium text-slate-500 dark:text-slate-300">Classification Details</h4>
            <div className="mt-2 flex flex-wrap items-center gap-2 text-sm">
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">
                SVM Algorithm
              </span>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200">
                70:30 Split
              </span>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200">
                Multi-parameter
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
