import { spawn } from 'child_process';
import fs from 'fs/promises';
import { BloodReportInsert, AnalysisResponse } from '@shared/schema';
import os from 'os';
import path from 'path';
import { randomUUID } from 'crypto';

/**
 * This file contains functions to interact with the Python SVM machine learning model.
 * It uses Node's child_process to execute Python scripts.
 */

/**
 * Analyze blood report data using an SVM model
 */
export async function analyzeBloodReport(data: BloodReportInsert, datasetPath?: string): Promise<AnalysisResponse> {
  try {
    // Create a temporary JSON file with the input data
    const inputFile = await createTempJsonFile(data);
    
    // Prepare command arguments
    const args = [
      '-c', 
      `
import sys
import json
import numpy as np
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

# Load input data
with open('${inputFile}', 'r') as f:
    input_data = json.load(f)

# Default dataset if none is provided
default_data = {
    "features": [
        [12.5, 95, 110, 5.2, 45, 22.5],
        [13.2, 105, 120, 5.5, 50, 24.0],
        [11.8, 125, 150, 6.2, 55, 26.5],
        [12.0, 130, 165, 6.5, 60, 27.0],
        [13.5, 85, 105, 5.0, 35, 21.0],
        [14.0, 90, 110, 5.1, 40, 22.0],
        [11.5, 140, 170, 7.0, 65, 29.0],
        [12.2, 120, 145, 6.0, 52, 25.5],
        [13.0, 100, 115, 5.4, 48, 23.5],
        [11.0, 145, 180, 7.5, 70, 31.0]
    ],
    "labels": [0, 0, 1, 1, 0, 0, 2, 1, 0, 2]
}

# Transform input data to feature array
input_features = [
    input_data['haemoglobin'],
    input_data['fastingGlucose'],
    input_data.get('randomGlucose', 0),  # Optional field
    input_data['hba1c'],
    input_data['age'],
    input_data['bmi']
]

# Train the SVM model
X = np.array(default_data['features'])
y = np.array(default_data['labels'])

# Split the data with 70:30 ratio
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Normalize features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train SVM classifier
svm_model = SVC(kernel='rbf', probability=True)
svm_model.fit(X_train_scaled, y_train)

# Prepare input for prediction
input_features_array = np.array([input_features])
input_features_scaled = scaler.transform(input_features_array)

# Make prediction
prediction = svm_model.predict(input_features_scaled)[0]
prediction_proba = svm_model.predict_proba(input_features_scaled)[0]
confidence = max(prediction_proba) * 100

# Define the status based on prediction
status_map = {0: "Normal", 1: "Pre-diabetic", 2: "Diabetic"}
status = status_map[prediction]
is_diabetic = 1 if prediction > 0 else 0  # Convert boolean to integer for JSON serialization

# Generate personalized recommendations
recommendations = {
    "diet": {
        "include": [],
        "avoid": []
    },
    "exercise": [],
    "lifestyle": []
}

# Diet recommendations
if prediction == 0:  # Normal
    recommendations["diet"]["include"] = [
        "Whole grains (brown rice, oats, quinoa)",
        "Lean proteins (chicken, fish, tofu)",
        "Variety of fruits and vegetables",
        "Low-fat dairy products"
    ]
    recommendations["diet"]["avoid"] = [
        "Excessive sugar and sweets",
        "Processed foods high in sodium",
        "Trans fats and fried foods",
        "Excessive alcohol consumption"
    ]
elif prediction == 1:  # Pre-diabetic
    recommendations["diet"]["include"] = [
        "High-fiber foods (whole grains, legumes)",
        "Lean proteins (fish, skinless poultry)",
        "Non-starchy vegetables",
        "Healthy fats (avocados, nuts, olive oil)"
    ]
    recommendations["diet"]["avoid"] = [
        "Refined carbohydrates (white bread, pastries)",
        "Sugary beverages and foods",
        "Processed snacks and fast food",
        "High-sodium processed meats"
    ]
else:  # Diabetic
    recommendations["diet"]["include"] = [
        "Complex carbohydrates (whole grains, legumes)",
        "Fiber-rich foods (vegetables, fruits with skin)",
        "Plant-based proteins (beans, lentils)",
        "Omega-3 rich foods (fatty fish, flaxseeds)"
    ]
    recommendations["diet"]["avoid"] = [
        "Simple sugars and sweets",
        "White bread, white rice, regular pasta",
        "Fried foods and saturated fats",
        "Fruit juices and sweetened beverages"
    ]

# Exercise recommendations
base_exercises = [
    {"name": "Walking", "duration": "30 minutes", "frequency": "daily", "icon": "walking"},
    {"name": "Cycling", "duration": "20-30 minutes", "frequency": "3 times weekly", "icon": "bicycle"}
]

if prediction == 0:  # Normal
    recommendations["exercise"] = base_exercises + [
        {"name": "Recreational sports", "duration": "45-60 minutes", "frequency": "2-3 times weekly", "icon": "basketball-ball"}
    ]
elif prediction == 1:  # Pre-diabetic
    recommendations["exercise"] = base_exercises + [
        {"name": "Strength Training", "duration": "15-20 minutes", "frequency": "2-3 times weekly", "icon": "dumbbell"},
        {"name": "Swimming", "duration": "20-30 minutes", "frequency": "2 times weekly", "icon": "swimming-pool"}
    ]
else:  # Diabetic
    recommendations["exercise"] = base_exercises + [
        {"name": "Strength Training", "duration": "15-20 minutes", "frequency": "2-3 times weekly", "icon": "dumbbell"},
        {"name": "Low-impact cardio", "duration": "15-20 minutes", "frequency": "3-4 times weekly", "icon": "heartbeat"},
        {"name": "Yoga", "duration": "20 minutes", "frequency": "2-3 times weekly", "icon": "om"}
    ]

# Lifestyle recommendations
base_lifestyle = [
    {"name": "Regular Meal Timing", "description": "Maintain consistent meal schedule", "icon": "clock"},
    {"name": "Quality Sleep", "description": "7-8 hours nightly", "icon": "moon"}
]

if prediction == 0:  # Normal
    recommendations["lifestyle"] = base_lifestyle + [
        {"name": "Hydration", "description": "8-10 glasses of water daily", "icon": "tint"}
    ]
elif prediction == 1:  # Pre-diabetic
    recommendations["lifestyle"] = base_lifestyle + [
        {"name": "Hydration", "description": "8-10 glasses of water daily", "icon": "tint"},
        {"name": "Stress Management", "description": "Practice mindfulness and relaxation techniques", "icon": "peace"}
    ]
else:  # Diabetic
    recommendations["lifestyle"] = base_lifestyle + [
        {"name": "Hydration", "description": "8-10 glasses of water daily", "icon": "tint"},
        {"name": "Stress Management", "description": "Practice mindfulness and relaxation techniques", "icon": "peace"},
        {"name": "Avoid Smoking", "description": "Quit smoking and avoid second-hand smoke", "icon": "ban"},
        {"name": "Monitor Blood Sugar", "description": "Check blood glucose levels regularly", "icon": "microscope"}
    ]

# Create result object
result = {
    "isDiabetic": is_diabetic,
    "diabetesStatus": status,
    "confidenceScore": confidence,
    "recommendations": recommendations
}

# Output as JSON
print(json.dumps(result))
      `
    ];

    // Execute Python analysis
    const result = await executePython(args);
    
    // Cleanup temp file
    await fs.unlink(inputFile);
    
    return JSON.parse(result) as AnalysisResponse;
  } catch (error) {
    console.error('Error analyzing blood report:', error);
    throw new Error('Failed to analyze blood report data');
  }
}

/**
 * Execute Python code and return the output
 */
async function executePython(args: string[]): Promise<string> {
  return new Promise((resolve, reject) => {
    const python = spawn('python3', args);
    
    let output = '';
    let errorOutput = '';
    
    python.stdout.on('data', (data) => {
      output += data.toString();
    });
    
    python.stderr.on('data', (data) => {
      errorOutput += data.toString();
    });
    
    python.on('close', (code) => {
      if (code !== 0) {
        console.error(`Python process exited with code ${code}`);
        console.error(`Python error output: ${errorOutput}`);
        reject(new Error(`Python execution failed: ${errorOutput}`));
      } else {
        resolve(output);
      }
    });
  });
}

/**
 * Create a temporary JSON file with input data
 */
async function createTempJsonFile(data: object): Promise<string> {
  const tempFile = path.join(os.tmpdir(), `${randomUUID()}.json`);
  await fs.writeFile(tempFile, JSON.stringify(data));
  return tempFile;
}
