import { db } from "@db";
import { 
  users, 
  bloodReports, 
  datasets, 
  recommendations,
  type BloodReportInsert,
  type AnalysisResponse
} from "@shared/schema";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";
import fs from "fs/promises";
import path from "path";
import os from "os";

// Helper function to save a file
export async function saveFile(fileBuffer: Buffer, fileName: string): Promise<string> {
  const uniqueId = randomUUID();
  const fileExtension = path.extname(fileName);
  const uniqueFileName = `${uniqueId}${fileExtension}`;
  const filePath = path.join(os.tmpdir(), uniqueFileName);
  
  await fs.writeFile(filePath, fileBuffer);
  return filePath;
}

// Create a new blood report and associated recommendations
export async function createBloodReport(
  data: BloodReportInsert, 
  analysisResults: AnalysisResponse,
  userId?: number
): Promise<number> {
  const [report] = await db.insert(bloodReports).values({
    ...data,
    userId: userId,
    isDiabetic: analysisResults.isDiabetic,
    diabetesStatus: analysisResults.diabetesStatus,
    confidenceScore: analysisResults.confidenceScore,
  }).returning({ id: bloodReports.id });

  // Save recommendations
  await db.insert(recommendations).values({
    reportId: report.id,
    dietRecommendations: JSON.stringify(analysisResults.recommendations.diet),
    exerciseRecommendations: JSON.stringify(analysisResults.recommendations.exercise),
    lifestyleRecommendations: JSON.stringify(analysisResults.recommendations.lifestyle),
  });

  return report.id;
}

// Upload a custom dataset for model training
export async function saveDataset(
  fileBuffer: Buffer, 
  fileName: string, 
  name: string, 
  description?: string, 
  userId?: number
): Promise<number> {
  const filePath = await saveFile(fileBuffer, fileName);
  
  const [dataset] = await db.insert(datasets).values({
    userId: userId,
    name: name,
    description: description,
    filePath: filePath,
  }).returning({ id: datasets.id });
  
  return dataset.id;
}

// Get a blood report by id
export async function getBloodReportById(id: number) {
  return await db.query.bloodReports.findFirst({
    where: eq(bloodReports.id, id),
    with: {
      recommendations: true,
    },
  });
}

// Get all blood reports for a user
export async function getBloodReportsByUserId(userId: number) {
  return await db.query.bloodReports.findMany({
    where: eq(bloodReports.userId, userId),
    orderBy: (bloodReports, { desc }) => [desc(bloodReports.createdAt)],
  });
}

// Get a dataset by id
export async function getDatasetById(id: number) {
  return await db.query.datasets.findFirst({
    where: eq(datasets.id, id),
  });
}

// Get all datasets for a user
export async function getDatasetsByUserId(userId: number) {
  return await db.query.datasets.findMany({
    where: eq(datasets.userId, userId),
    orderBy: (datasets, { desc }) => [desc(datasets.createdAt)],
  });
}
