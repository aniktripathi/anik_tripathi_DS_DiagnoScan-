import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import * as storage from "./storage";
import { analyzeBloodReport } from "./ml";
import { bloodReportInsertSchema, datasetInsertSchema, BloodReportInsert } from "@shared/schema";
import multer from "multer";
import csvtojson from "csvtojson";
import { ZodError } from "zod";

// Set up multer for file uploads
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }, // Limit file size to 5MB
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint
  app.get('/api/health', (_req, res) => {
    res.status(200).json({ status: 'healthy' });
  });

  // Analyze blood report from manual entry
  app.post('/api/analyze', async (req: Request, res: Response) => {
    try {
      // Validate request body
      const data = bloodReportInsertSchema.parse(req.body);
      
      // Analyze the blood report data
      const analysisResults = await analyzeBloodReport(data);
      
      // Store the report and analysis in database
      const reportId = await storage.createBloodReport(data, analysisResults);
      
      // Return the analysis results
      res.status(200).json({
        reportId,
        ...analysisResults
      });
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ 
          message: 'Invalid blood report data', 
          errors: error.errors 
        });
      } else {
        console.error('Error analyzing report:', error);
        res.status(500).json({ message: 'Failed to analyze blood report' });
      }
    }
  });

  // Analyze blood report from PDF upload
  app.post('/api/analyze/pdf', upload.single('file'), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No PDF file uploaded' });
      }
      
      console.log('PDF file received with size:', req.file.size, 'bytes');

      // Extract values from form fields if available
      const formData = req.body;
      
      // Create a blood report data object with values from form fields
      const bloodReportData: Partial<BloodReportInsert> = {
        // Core parameters with defaults
        haemoglobin: formData.haemoglobin ? parseFloat(formData.haemoglobin) : 14.5,
        fastingGlucose: formData.fastingGlucose ? parseFloat(formData.fastingGlucose) : 105,
        hba1c: formData.hba1c ? parseFloat(formData.hba1c) : 5.9,
        age: formData.age ? parseInt(formData.age) : 42,
        bmi: formData.bmi ? parseFloat(formData.bmi) : 24.5,
      };
      
      // Add optional parameters if provided in form data
      if (formData.randomGlucose) {
        bloodReportData.randomGlucose = parseFloat(formData.randomGlucose);
      }
      
      // Blood cell counts
      if (formData.rbc) bloodReportData.rbc = parseFloat(formData.rbc);
      if (formData.wbc) bloodReportData.wbc = parseFloat(formData.wbc);
      if (formData.platelets) bloodReportData.platelets = parseFloat(formData.platelets);
      
      // Lipid profile
      if (formData.cholesterol) bloodReportData.cholesterol = parseFloat(formData.cholesterol);
      if (formData.triglycerides) bloodReportData.triglycerides = parseFloat(formData.triglycerides);
      if (formData.hdl) bloodReportData.hdl = parseFloat(formData.hdl);
      if (formData.ldl) bloodReportData.ldl = parseFloat(formData.ldl);
      
      // Kidney function
      if (formData.creatinine) bloodReportData.creatinine = parseFloat(formData.creatinine);
      if (formData.urea) bloodReportData.urea = parseFloat(formData.urea);
      
      // Electrolytes
      if (formData.sodium) bloodReportData.sodium = parseFloat(formData.sodium);
      if (formData.potassium) bloodReportData.potassium = parseFloat(formData.potassium);
      if (formData.chloride) bloodReportData.chloride = parseFloat(formData.chloride);
      
      // Calculate BMI if height and weight are provided but bmi isn't
      if (!bloodReportData.bmi && formData.height && formData.weight) {
        const heightM = parseFloat(formData.height) / 100; // Convert cm to m
        const weight = parseFloat(formData.weight);
        bloodReportData.bmi = weight / (heightM * heightM);
      }
      
      // Log the extracted values for debugging
      console.log('Blood report data:', bloodReportData);
      
      // Validate the mapped data
      const data = bloodReportInsertSchema.parse(bloodReportData);
      
      // Analyze the blood report data
      const analysisResults = await analyzeBloodReport(data);
      
      // Store the report and analysis in database
      const reportId = await storage.createBloodReport(data, analysisResults);
      
      // Return the analysis results
      res.status(200).json({
        reportId,
        ...analysisResults
      });
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ 
          message: 'Invalid PDF data', 
          errors: error.errors 
        });
      } else {
        console.error('Error analyzing PDF report:', error);
        res.status(500).json({ message: 'Failed to analyze PDF blood report' });
      }
    }
  });

  // Upload custom dataset for model training
  app.post('/api/datasets', upload.single('file'), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No dataset file uploaded' });
      }
      
      const { name, description } = req.body;
      
      // Validate dataset metadata
      const metadata = datasetInsertSchema.parse({
        name,
        description
      });
      
      // Save the dataset
      const datasetId = await storage.saveDataset(
        req.file.buffer,
        req.file.originalname,
        metadata.name,
        metadata.description
      );
      
      res.status(201).json({ 
        message: 'Dataset uploaded successfully',
        datasetId
      });
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ 
          message: 'Invalid dataset metadata', 
          errors: error.errors 
        });
      } else {
        console.error('Error uploading dataset:', error);
        res.status(500).json({ message: 'Failed to upload dataset' });
      }
    }
  });

  // Get a specific blood report
  app.get('/api/reports/:id', async (req: Request, res: Response) => {
    try {
      const reportId = parseInt(req.params.id);
      
      if (isNaN(reportId)) {
        return res.status(400).json({ message: 'Invalid report ID' });
      }
      
      const report = await storage.getBloodReportById(reportId);
      
      if (!report) {
        return res.status(404).json({ message: 'Blood report not found' });
      }
      
      res.status(200).json(report);
    } catch (error) {
      console.error('Error retrieving blood report:', error);
      res.status(500).json({ message: 'Failed to retrieve blood report' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
