import { pgTable, text, serial, integer, boolean, doublePrecision, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// User table for authentication and user management
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Blood report data
export const bloodReports = pgTable("blood_reports", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  haemoglobin: doublePrecision("haemoglobin").notNull(),
  fastingGlucose: doublePrecision("fasting_glucose").notNull(),
  randomGlucose: doublePrecision("random_glucose"),
  hba1c: doublePrecision("hba1c").notNull(),
  rbc: doublePrecision("rbc"),
  wbc: doublePrecision("wbc"),
  platelets: doublePrecision("platelets"),
  cholesterol: doublePrecision("cholesterol"),
  triglycerides: doublePrecision("triglycerides"),
  hdl: doublePrecision("hdl"),
  ldl: doublePrecision("ldl"),
  creatinine: doublePrecision("creatinine"),
  urea: doublePrecision("urea"),
  sodium: doublePrecision("sodium"),
  potassium: doublePrecision("potassium"),
  chloride: doublePrecision("chloride"),
  age: integer("age").notNull(),
  bmi: doublePrecision("bmi").notNull(),
  isDiabetic: boolean("is_diabetic"),
  diabetesStatus: text("diabetes_status"),
  confidenceScore: doublePrecision("confidence_score"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Custom datasets for model training
export const datasets = pgTable("datasets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  description: text("description"),
  filePath: text("file_path").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Health recommendations based on analysis
export const recommendations = pgTable("recommendations", {
  id: serial("id").primaryKey(),
  reportId: integer("report_id").references(() => bloodReports.id),
  dietRecommendations: text("diet_recommendations"),
  exerciseRecommendations: text("exercise_recommendations"),
  lifestyleRecommendations: text("lifestyle_recommendations"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  bloodReports: many(bloodReports),
  datasets: many(datasets),
}));

export const bloodReportsRelations = relations(bloodReports, ({ one, many }) => ({
  user: one(users, {
    fields: [bloodReports.userId],
    references: [users.id],
  }),
  recommendations: many(recommendations),
}));

export const datasetsRelations = relations(datasets, ({ one }) => ({
  user: one(users, {
    fields: [datasets.userId],
    references: [users.id],
  }),
}));

export const recommendationsRelations = relations(recommendations, ({ one }) => ({
  bloodReport: one(bloodReports, {
    fields: [recommendations.reportId],
    references: [bloodReports.id],
  }),
}));

// Schema validation
export const bloodReportInsertSchema = createInsertSchema(bloodReports)
  .omit({ id: true, userId: true, isDiabetic: true, diabetesStatus: true, confidenceScore: true, createdAt: true })
  .extend({
    haemoglobin: z.coerce.number().min(1, "Haemoglobin must be at least 1 g/dL").max(25, "Haemoglobin must be less than 25 g/dL"),
    fastingGlucose: z.coerce.number().min(50, "Fasting glucose must be at least 50 mg/dL").max(500, "Fasting glucose must be less than 500 mg/dL"),
    randomGlucose: z.coerce.number().min(50, "Random glucose must be at least 50 mg/dL").max(500, "Random glucose must be less than 500 mg/dL").optional(),
    hba1c: z.coerce.number().min(3, "HbA1c must be at least 3%").max(15, "HbA1c must be less than 15%"),
    rbc: z.coerce.number().min(0.5, "RBC must be at least 0.5 million/μL").max(10, "RBC must be less than 10 million/μL").optional(),
    wbc: z.coerce.number().min(1, "WBC must be at least 1 thousand/μL").max(100, "WBC must be less than 100 thousand/μL").optional(),
    platelets: z.coerce.number().min(10, "Platelets must be at least 10 thousand/μL").max(1000, "Platelets must be less than 1000 thousand/μL").optional(),
    cholesterol: z.coerce.number().min(50, "Cholesterol must be at least 50 mg/dL").max(500, "Cholesterol must be less than 500 mg/dL").optional(),
    triglycerides: z.coerce.number().min(20, "Triglycerides must be at least 20 mg/dL").max(1000, "Triglycerides must be less than 1000 mg/dL").optional(),
    hdl: z.coerce.number().min(10, "HDL must be at least 10 mg/dL").max(100, "HDL must be less than 100 mg/dL").optional(),
    ldl: z.coerce.number().min(20, "LDL must be at least 20 mg/dL").max(300, "LDL must be less than 300 mg/dL").optional(),
    creatinine: z.coerce.number().min(0.1, "Creatinine must be at least 0.1 mg/dL").max(10, "Creatinine must be less than 10 mg/dL").optional(),
    urea: z.coerce.number().min(5, "Urea must be at least 5 mg/dL").max(200, "Urea must be less than 200 mg/dL").optional(),
    sodium: z.coerce.number().min(110, "Sodium must be at least 110 mEq/L").max(180, "Sodium must be less than 180 mEq/L").optional(),
    potassium: z.coerce.number().min(2, "Potassium must be at least 2 mEq/L").max(8, "Potassium must be less than 8 mEq/L").optional(),
    chloride: z.coerce.number().min(80, "Chloride must be at least 80 mEq/L").max(120, "Chloride must be less than 120 mEq/L").optional(),
    age: z.coerce.number().int().min(1, "Age must be at least 1").max(120, "Age must be less than 120"),
    bmi: z.coerce.number().min(10, "BMI must be at least 10").max(50, "BMI must be less than 50"),
  });

export const datasetInsertSchema = createInsertSchema(datasets)
  .omit({ id: true, userId: true, createdAt: true })
  .extend({
    name: z.string().min(3, "Name must be at least 3 characters"),
    description: z.string().optional(),
  });

export type BloodReportInsert = z.infer<typeof bloodReportInsertSchema>;
export type BloodReport = typeof bloodReports.$inferSelect;
export type Dataset = typeof datasets.$inferSelect;
export type Recommendation = typeof recommendations.$inferSelect;
export type User = typeof users.$inferSelect;

// Analysis response schema
export const analysisResponseSchema = z.object({
  isDiabetic: z.number().or(z.boolean()),
  diabetesStatus: z.enum(["Normal", "Pre-diabetic", "Diabetic"]),
  confidenceScore: z.number().min(0).max(100),
  recommendations: z.object({
    diet: z.object({
      include: z.array(z.string()),
      avoid: z.array(z.string()),
    }),
    exercise: z.array(z.object({
      name: z.string(),
      duration: z.string(),
      frequency: z.string(),
      icon: z.string().optional(),
    })),
    lifestyle: z.array(z.object({
      name: z.string(),
      description: z.string(),
      icon: z.string().optional(),
    })),
  }),
});

export type AnalysisResponse = z.infer<typeof analysisResponseSchema>;
